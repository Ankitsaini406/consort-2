import React from 'react';
import { AppFormRenderer } from '@/app/admin/forms/components/AppFormRenderer';
import { productFormConfig } from '../config/productFormConfig';
import { ProductFormData } from '../types';

// Updated imports for base StepProgress and StepCard
import { StepProgress } from '@/app/admin/forms/components/shared/layout/StepProgress';
import { StepCard } from '@/app/admin/forms/components/shared/layout/StepCard';
import { UniversalFormActions } from '@/app/admin/forms/components/shared/layout/UniversalFormActions';
import { doc, setDoc } from 'firebase/firestore';
import { db } from '@/firebase/firebaseconfig';
import { FormErrorHandler, UserNotification, InputSanitizer } from '@/app/admin/forms/utils/errorHandler';
import { RateLimiter, withRateLimit } from '@/app/admin/forms/utils/rateLimiter';
import { FileUploadSecurity, ALLOWED_FILE_TYPES, FILE_SIZE_LIMITS } from '@/app/admin/forms/utils/fileUploadSecurity';
import { createSlug } from '@/utils/Utils';
import { removeFileObjects, uploadDoc } from '@/firebase/firebaseAuth';

const sanitizeProductData = (data: ProductFormData): ProductFormData => {
    return {
        ...data,
        productName: InputSanitizer.sanitizeString(data.productName || ''),
        marketingTagline: InputSanitizer.sanitizeString(data.marketingTagline || ''),
        productOverview: InputSanitizer.sanitizeString(data.productOverview || ''),
        // Sanitize key features
        keyFeatures: data.keyFeatures?.map(kf => ({
            ...kf,
            description: InputSanitizer.sanitizeString(kf.description || '')
        })) || [],
        // Sanitize marketing highlights
        marketingHighlights: data.marketingHighlights?.map(h => ({
            ...h,
            headline: InputSanitizer.sanitizeString(h.headline || ''),
            description: InputSanitizer.sanitizeString(h.description || '')
        })) || [],
        // Preserve file objects
        productGallery: data.productGallery || [],
        datasheetFile: data.datasheetFile,
        brochureFile: data.brochureFile,
        caseStudyFile: data.caseStudyFile
    };
};

const validateFileUniqueness = (files: File[]): boolean => {
    const fileNames = new Set<string>();
    const fileSizes = new Set<number>();
    
    for (const file of files) {
        const key = `${file.name}-${file.size}`;
        if (fileNames.has(key)) {
            return false;
        }
        fileNames.add(key);
        fileSizes.add(file.size);
    }
    
    return true;
};

const validateFiles = async (data: ProductFormData): Promise<string[]> => {
    const errors: string[] = [];
    
    // Check for duplicate files in product gallery
    if (data.productGallery && data.productGallery.length > 0) {
        if (!validateFileUniqueness(data.productGallery)) {
            errors.push('Duplicate files detected in product gallery');
        }
        
        for (const file of data.productGallery) {
            const validation = await FileUploadSecurity.validateFile(file, {
                allowedTypes: [...ALLOWED_FILE_TYPES.images],
                maxSize: FILE_SIZE_LIMITS.image,
                requireSignatureValidation: true
            });
            
            if (!validation.isValid) {
                errors.push(`Product photo "${file.name}": ${validation.errors.join(', ')}`);
            }
        }
    }
    
    // Check for duplicate files in marketing highlights
    if (data.marketingHighlights) {
        for (const highlight of data.marketingHighlights) {
            if (highlight.visuals && highlight.visuals.length > 0) {
                if (!validateFileUniqueness(highlight.visuals)) {
                    errors.push(`Duplicate files detected in marketing highlight "${highlight.headline}"`);
                }
                
                for (const file of highlight.visuals) {
                    const validation = await FileUploadSecurity.validateFile(file, {
                        allowedTypes: [...ALLOWED_FILE_TYPES.images],
                        maxSize: FILE_SIZE_LIMITS.image,
                        requireSignatureValidation: true
                    });
                    
                    if (!validation.isValid) {
                        errors.push(`Marketing highlight visual "${file.name}": ${validation.errors.join(', ')}`);
                    }
                }
            }
        }
    }
    
    // Validate resource files
    const resourceFiles = [
        data.datasheetFile,
        data.brochureFile,
        data.caseStudyFile
    ].filter(Boolean) as File[];
    
    if (resourceFiles.length > 0) {
        if (!validateFileUniqueness(resourceFiles)) {
            errors.push('Duplicate files detected in resource files');
        }
        
        for (const file of resourceFiles) {
            const validation = await FileUploadSecurity.validateFile(file, {
                allowedTypes: [...ALLOWED_FILE_TYPES.documents, ...ALLOWED_FILE_TYPES.images],
                maxSize: FILE_SIZE_LIMITS.document,
                requireSignatureValidation: true
            });
            
            if (!validation.isValid) {
                errors.push(`Resource file "${file.name}": ${validation.errors.join(', ')}`);
            }
        }
    }
    
    return errors;
};

const handleProductFormSubmit = async (data: ProductFormData, isDraft?: boolean) => {
    const context = 'ProductForm';
    const clientId = RateLimiter.getClientIdentifier();
    
    try {
        await withRateLimit(clientId, 'formSubmission', async () => {
            console.log(`[${context}] Submit started:`, { isDraft });
            
            // Validate files first
            const fileErrors = await validateFiles(data);
            if (fileErrors.length > 0) {
                throw new Error(`File validation failed: ${fileErrors.join('; ')}`);
            }
            
            // Sanitize input data
            const sanitizedData = sanitizeProductData(data);
            const slug = createSlug(sanitizedData.productName);

            // Create a batch of upload promises
            const uploadPromises: Promise<{ type: string; url: string }>[] = [];

            // Handle product gallery uploads
            if (sanitizedData.productGallery?.length > 0) {
                sanitizedData.productGallery.forEach((file, index) => {
                    const timestamp = Date.now();
                    const uniqueId = `${timestamp}-${index}`;
                    uploadPromises.push(
                        uploadDoc(`products/${slug}/gallery/${uniqueId}`, file)
                            .then(url => ({ type: 'gallery', url }))
                    );
                });
            }

            // Handle resource file uploads
            if (sanitizedData.datasheetFile) {
                uploadPromises.push(
                    uploadDoc(`products/${slug}/datasheets/${Date.now()}-datasheet`, sanitizedData.datasheetFile)
                        .then(url => ({ type: 'datasheet', url }))
                );
            }
            if (sanitizedData.brochureFile) {
                uploadPromises.push(
                    uploadDoc(`products/${slug}/brochures/${Date.now()}-brochure`, sanitizedData.brochureFile)
                        .then(url => ({ type: 'brochure', url }))
                );
            }
            if (sanitizedData.caseStudyFile) {
                uploadPromises.push(
                    uploadDoc(`products/${slug}/case-studies/${Date.now()}-casestudy`, sanitizedData.caseStudyFile)
                        .then(url => ({ type: 'casestudy', url }))
                );
            }

            // Handle marketing highlights file uploads
            const marketingHighlightsPromises = sanitizedData.marketingHighlights.map(async (highlight, index) => {
                const visualUrls = await Promise.all(
                    highlight.visuals.map(async (file, visualIndex) => {
                        const timestamp = Date.now();
                        const uniqueId = `${timestamp}-${index}-${visualIndex}`;
                        return uploadDoc(`products/${slug}/marketing-highlights/${uniqueId}`, file);
                    })
                );
                return {
                    ...highlight,
                    visualUrls
                };
            });

            // Wait for all uploads to complete
            const [uploadResults, marketingHighlights] = await Promise.all([
                Promise.all(uploadPromises),
                Promise.all(marketingHighlightsPromises)
            ]);

            // Process upload results
            const productGalleryUrls: string[] = [];
            let datasheetUrl: string | null = null;
            let brochureUrl: string | null = null;
            let caseStudyUrl: string | null = null;

            uploadResults.forEach(result => {
                switch (result.type) {
                    case 'gallery':
                        productGalleryUrls.push(result.url);
                        break;
                    case 'datasheet':
                        datasheetUrl = result.url;
                        break;
                    case 'brochure':
                        brochureUrl = result.url;
                        break;
                    case 'casestudy':
                        caseStudyUrl = result.url;
                        break;
                }
            });

            // Create the final product data
            const productData: ProductFormData = {
                ...sanitizedData,
                slug,
                productGalleryUrls,
                datasheetUrl,
                brochureUrl,
                caseStudyUrl,
                marketingHighlights,
                fileMetadata: {
                    lastUpdated: new Date().toISOString(),
                    galleryCount: productGalleryUrls.length,
                    highlightCount: marketingHighlights.length,
                    resourceCount: [datasheetUrl, brochureUrl, caseStudyUrl].filter(Boolean).length
                }
            };

            // Remove any remaining File objects before saving to Firestore
            const cleanData = removeFileObjects(productData);
            
            console.log(`[${context}] Final product payload ready.`, cleanData);
            
            // Add document to Firebase
            await setDoc(doc(db, 'products', slug), cleanData);
            
            // Success notification
            UserNotification.showSuccess(`Product "${sanitizedData.productName}" saved successfully with ID: ${slug}`);
            console.log(`[${context}] Submit successful:`, { docId: slug });
        });
        
    } catch (error) {
        // Handle and log error
        const formError = FormErrorHandler.handleError(error);
        FormErrorHandler.logError(error, context);
        UserNotification.showError(formError);
        
        // Re-throw to let the form handle the error state
        throw error;
    }
};

// Product-specific FormActions wrapper
const ProductFormActions: React.FC<React.ComponentProps<typeof UniversalFormActions>> = (props) => (
    <UniversalFormActions {...props} submitText="Submit Product" />
);

export const ProductForm: React.FC = () => {
    const configWithActualSubmit = {
        ...productFormConfig,
        onSubmit: handleProductFormSubmit,
    };

    return (
        <AppFormRenderer<ProductFormData>
            formConfig={configWithActualSubmit}
            StepProgressComponent={StepProgress}
            StepCardComponent={StepCard}
            FormActionsComponent={ProductFormActions}
        />
    );
};