import React from 'react';
import { ProductFormData, KeyFeature, BulletPoint } from '../types';
import { 
    SummaryCard, 
    GridFieldDisplay, 
    BaseReviewStepProps, 
    ReviewStepContainer,
    EmptyState,
    NestedGrid,
    SectionDivider
} from '@/app/admin/forms/components/shared/layout/SummaryCard';

interface ReviewStepProps extends BaseReviewStepProps<ProductFormData> {
    onEditSection: (stepId: number | string) => void;
}

export const ReviewStep: React.FC<ReviewStepProps> = ({ 
    formData, 
    onEditSection, 
    className 
}) => {
    const stepIds = {
        productDetails: 1,
        productBrief: 2,
        resources: 3,
        highlights: 4,
    };

    return (
        <ReviewStepContainer className={className}>
            <SummaryCard 
                title="Product Details" 
                onEdit={() => onEditSection(stepIds.productDetails)}
                useGrid={true}
            >
                <GridFieldDisplay 
                    label="Portfolio Category" 
                    value={formData.portfolioCategory}
                />
                <GridFieldDisplay 
                    label="Brand Name" 
                    value={formData.brandName}
                />
                <GridFieldDisplay 
                    label="Target Industries" 
                    value={formData.targetIndustries}
                    type="tags" 
                />
                <GridFieldDisplay 
                    label="Client Companies" 
                    value={formData.clientCompanies}
                    type="tags" 
                />
                <GridFieldDisplay 
                    label="Global Tags" 
                    value={formData.globalTags}
                    type="tags" 
                    colSpan={2}
                />
                <GridFieldDisplay 
                    label="Product Name" 
                    value={formData.productName} 
                />
                <GridFieldDisplay 
                    label="Marketing Tagline" 
                    value={formData.marketingTagline}
                    type="textarea"
                    colSpan={1}
                />
                <GridFieldDisplay 
                    label="Product Gallery" 
                    value={Array.isArray(formData.productGallery) ? formData.productGallery.map(photo => photo.name || 'Uploaded file') : []}
                    type="files" 
                    colSpan={2}
                />
            </SummaryCard>

            <SummaryCard 
                title="Product Brief" 
                onEdit={() => onEditSection(stepIds.productBrief)}
                useGrid={true}
            >
                <GridFieldDisplay 
                    label="Product Overview" 
                    value={formData.productOverview}
                    type="textarea"
                    colSpan={2}
                />
                <GridFieldDisplay 
                    label="Detailed Description" 
                    value={formData.productText}
                    type="textarea"
                    colSpan={2}
                />
                <GridFieldDisplay 
                    label="Bullet Points" 
                    value={Array.isArray(formData.bulletPoints) ? formData.bulletPoints.map(bp => bp.point) : []}
                    type="list"
                    colSpan={1}
                />
                <GridFieldDisplay 
                    label="Key Features" 
                    value={Array.isArray(formData.keyFeatures) ? formData.keyFeatures.map(kf => kf.keyFeature) : []}
                    type="list"
                    colSpan={1}
                />
            </SummaryCard>

            <SummaryCard 
                title="Product Resources" 
                onEdit={() => onEditSection(stepIds.resources)}
                useGrid={true}
            >
                <GridFieldDisplay 
                    label="Datasheet" 
                    value={formData.datasheetFile?.name}
                    type="file" 
                />
                <GridFieldDisplay 
                    label="Brochure" 
                    value={formData.brochureFile?.name}
                    type="file" 
                />
                <GridFieldDisplay 
                    label="Case Study" 
                    value={formData.caseStudyFile?.name}
                    type="file" 
                />
            </SummaryCard>

            <SummaryCard 
                title="Marketing Highlights" 
                onEdit={() => onEditSection(stepIds.highlights)}
                useGrid={false}
            >
                {Array.isArray(formData.marketingHighlights) && formData.marketingHighlights.length > 0 ? (
                    formData.marketingHighlights.map((highlight, index) => (
                        <SectionDivider 
                            key={highlight.id || index} 
                            isLast={index === formData.marketingHighlights.length - 1}
                        >
                            <NestedGrid>
                                <GridFieldDisplay 
                                    label="Headline" 
                                    value={highlight.headline} 
                                />
                                <GridFieldDisplay 
                                    label="Visuals" 
                                    value={Array.isArray(highlight.visuals) ? highlight.visuals.map(visual => visual.name || 'Uploaded file') : []} 
                                    type="files"
                                    colSpan={1}
                                />
                                <GridFieldDisplay 
                                    label="Description" 
                                    value={highlight.description} 
                                    type="textarea"
                                    colSpan={2}
                                />
                            </NestedGrid>
                        </SectionDivider>
                    ))
                ) : (
                    <EmptyState message="No marketing highlights added." />
                )}
            </SummaryCard>
        </ReviewStepContainer>
    );
}; 