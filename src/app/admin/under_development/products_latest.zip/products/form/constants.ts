export const PRODUCT_CATEGORIES = [
    { label: 'Communication', value: 'communication' },
    { label: 'Communication2', value: 'communication2' },
    { label: 'Communication3', value: 'communication3' },
    { label: 'Communication4', value: 'communication4' },
    { label: 'Communication5', value: 'communication5' },
    { label: 'Communication6', value: 'communication6' },
    { label: 'Communication7', value: 'communication7' },
    { label: 'Communication8', value: 'communication8' },
    { label: 'Navigation', value: 'navigation' },
    { label: 'Navigation2', value: 'navigation2' },
    { label: 'Navigation3', value: 'navigation3' },
    { label: 'Navigation4', value: 'navigation4' },
    { label: 'Navigation5', value: 'navigation5' },
    { label: 'Navigation6', value: 'navigation6' },
    { label: 'Navigation7', value: 'navigation7' },
    { label: 'Navigation8', value: 'navigation8' },
    { label: 'Surveillance', value: 'surveillance' },
    { label: 'Surveillance2', value: 'surveillance2' },
    { label: 'Surveillance3', value: 'surveillance3' },
    { label: 'Surveillance4', value: 'surveillance4' },
    { label: 'Surveillance5', value: 'surveillance5' },
    { label: 'Surveillance6', value: 'surveillance6' },
    { label: 'Surveillance7', value: 'surveillance7' },
    { label: 'Surveillance8', value: 'surveillance8' },
    
];

export const PRODUCT_SUBCATEGORIES = [
    { label: 'Radio Systems', value: 'radio' },
    { label: 'Radar Systems', value: 'radar' },
    { label: 'Satellite Systems', value: 'satellite' },
];

export const COMPANY_TAGS = [
    { label: 'Military', value: 'military' },
    { label: 'Commercial', value: 'commercial' },
    { label: 'Aerospace', value: 'aerospace' },
];

export const FEATURE_TYPES = [
    { value: "technical", label: "Technical" },
    { value: "functional", label: "Functional" },
    { value: "performance", label: "Performance" },
    { value: "security", label: "Security" },
    { value: "integration", label: "Integration" },
    { value: "other", label: "Other" }
];

export const FILE_UPLOAD_CONFIG = {
    PRODUCT_PHOTOS: {
        accept: 'image/*',
        maxFiles: 4,
        maxSize: 500 * 1024, // 500KB
    },
    DOCUMENTS: {
        accept: '.pdf',
        maxSize: 5 * 1024 * 1024, // 5MB
    },
};

export const REQUIRED_FIELDS = [
    'productName',
    'briefHeadline',
    'briefDescription',
    'category',
] as const;

export const FORM_VALIDATION_MESSAGES = {
    required: (field: string) => `${field} is required`,
    maxFiles: (max: number) => `Maximum ${max} files allowed`,
    maxFileSize: (size: number) => `File size should not exceed ${size / 1024}KB`,
    invalidFileType: 'Invalid file type',
}; 