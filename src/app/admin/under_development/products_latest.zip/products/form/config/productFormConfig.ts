import { FormConfig, FormFieldType } from '@/app/admin/forms/types';
import { ProductFormData } from '../types';
import { PRODUCT_CATEGORIES, PRODUCT_SUBCATEGORIES, COMPANY_TAGS, FILE_UPLOAD_CONFIG } from '../constants';

import { ReviewStep } from '../components/ReviewStep';
import { BaseReviewStepProps } from '@/app/admin/forms/components/shared/layout/ReviewStepTypes';

// Global tags options - this should ideally come from a shared constants file
const GLOBAL_TAGS_OPTIONS = [
    { value: 'ai', label: 'Artificial Intelligence' },
    { value: 'iot', label: 'Internet of Things' },
    { value: 'cloud', label: 'Cloud Computing' },
    { value: 'digital-transformation', label: 'Digital Transformation' },
    { value: 'automation', label: 'Automation' },
    { value: 'analytics', label: 'Analytics' },
    { value: 'security', label: 'Security' },
    { value: 'connectivity', label: 'Connectivity' },
    { value: 'innovation', label: 'Innovation' },
    { value: 'efficiency', label: 'Efficiency' },
];

const initialProductFormData: ProductFormData = {
    // Product Details
    portfolioCategory: "",
    slug: "",
    targetIndustries: [],
    brandName: "",
    clientCompanies: [],
    globalTags: [],
    productName: "",
    marketingTagline: "",
    productGallery: [],
    productOverview: "",
    productText: "",
    keyFeatures: [{ id: "1", keyFeature: "", icon: "" }],
    bulletPoints: [],
    
    // Resource Files
    datasheetFile: null,
    brochureFile: null,
    caseStudyFile: null,
    
    // Marketing Highlights
    marketingHighlights: [{ id: "1", headline: "", description: "", visuals: [] }],
    
    // Metadata
    fileMetadata: {
        lastUpdated: new Date().toISOString(),
        galleryCount: 0,
        highlightCount: 0,
        resourceCount: 0
    }
};

export const productFormConfig: FormConfig<ProductFormData> = {
    formId: 'product-form',
    formTitle: 'Add Product',
    description: 'Fill in the details to add a new product to the catalog.',
    initialData: initialProductFormData,
    onSubmit: async (data, isDraft) => {
        console.log('Submitting Product Form:', data, 'Is Draft:', isDraft);
        // Replace with actual API submission logic
        await new Promise(resolve => setTimeout(resolve, 1000)); // Simulate API call
        if (data.productName === "fail") { // Example error condition
            throw new Error("Simulated server error: Product name cannot be 'fail'.");
        }
    },
    steps: [
        {
            id: 1,
            title: 'Product Details',
            subtitle: 'Product categorization and basic information',
            fields: [
                {
                    id: 'portfolioCategory',
                    label: 'Select Portfolio Category',
                    type: 'select' as FormFieldType,
                    placeholder: 'Select portfolio category',
                    options: PRODUCT_CATEGORIES,
                    validation: { required: true },
                    colSpan: 1,
                },
                {
                    id: 'targetIndustries',
                    label: 'Target Industries',
                    type: 'multi-select' as FormFieldType,
                    placeholder: 'Select target industries',
                    options: PRODUCT_CATEGORIES,
                    validation: { required: true },
                    colSpan: 3,
                },
                {
                    id: 'brandName',
                    label: 'Select Brand',
                    type: 'select' as FormFieldType,
                    placeholder: 'Select brand',
                    options: PRODUCT_SUBCATEGORIES,
                    validation: { required: false },
                    colSpan: 1,
                },
                {
                    id: 'clientCompanies',
                    label: 'Client Companies',
                    type: 'multi-select' as FormFieldType,
                    placeholder: 'Select client companies',
                    options: COMPANY_TAGS,
                    validation: { required: false },
                    colSpan: 3,
                },
                {
                    id: 'globalTags',
                    label: 'Global Tags',
                    type: 'multi-select' as FormFieldType,
                    placeholder: 'Select global tags for content linking',
                    options: GLOBAL_TAGS_OPTIONS,
                    validation: { required: false },
                    colSpan: 4,
                },
                {
                    id: 'productName',
                    label: 'Product Name',
                    type: 'input' as FormFieldType,
                    placeholder: 'Enter product name',
                    validation: { required: true, minLength: 3 },
                    colSpan: 4,
                },
                {
                    id: 'marketingTagline',
                    label: 'Marketing Tagline',
                    type: 'textarea' as FormFieldType,
                    placeholder: 'Enter marketing tagline',
                    validation: { required: true, minLength: 10 },
                    colSpan: 4,
                },
                {
                    id: 'productGallery',
                    label: 'Upload Product Gallery (up to 4 photos)',
                    type: 'file' as FormFieldType,
                    accept: FILE_UPLOAD_CONFIG.PRODUCT_PHOTOS.accept,
                    multiple: true,
                    maxFiles: FILE_UPLOAD_CONFIG.PRODUCT_PHOTOS.maxFiles,
                    validation: { 
                        required: false,
                        maxFiles: FILE_UPLOAD_CONFIG.PRODUCT_PHOTOS.maxFiles,
                        maxSize: FILE_UPLOAD_CONFIG.PRODUCT_PHOTOS.maxSize,
                        allowedTypes: FILE_UPLOAD_CONFIG.PRODUCT_PHOTOS.accept
                    },
                    colSpan: 4,
                    onChange: (value: unknown) => {
                        const files = value as File[];
                        // Validate file uniqueness
                        const uniqueFiles = new Set(files.map(f => `${f.name}-${f.size}`));
                        if (uniqueFiles.size !== files.length) {
                            throw new Error('Duplicate files detected. Please remove duplicates before uploading.');
                        }
                        return files;
                    }
                },
            ],
        },
        {
            id: 2,
            title: 'Product Brief',
            subtitle: 'Detailed product information',
            fields: [
                {
                    id: 'productOverview',
                    label: 'Overview',
                    type: 'textarea' as FormFieldType,
                    placeholder: 'Highlight Product Overview',
                    validation: { required: true, minLength: 20 },
                    className: 'min-h-[90px]',
                    colSpan: 2,
                },
                {
                    id: 'productText',
                    label: 'Detailed Description',
                    type: 'textarea' as FormFieldType,
                    placeholder: 'Enter detailed product text',
                    validation: { required: true, minLength: 20 },
                    className: 'min-h-[150px]',
                    colSpan: 2,
                },
                
                
                {
                    id: 'bulletPoints',
                    label: 'Bullet Points',
                    type: 'dynamic-section' as FormFieldType,
                    maxItems: 6,
                    minItems: 0,
                    addButtonText: 'Add Bullet Point',
                    removeButtonText: 'Remove',
                    itemTitle: 'Bullet Point',
                    itemFields: [
                        {
                            id: 'point',
                            label: 'Bullet Point',
                            type: 'input' as FormFieldType,
                            placeholder: 'Enter bullet point',
                            validation: { required: true },
                            colSpan: 4,
                            compact: true,
                        },
                    ],
                    validation: { required: false },
                    colSpan: 4,
                },
                
                {
                    id: 'keyFeatures',
                    label: 'Key Features',
                    type: 'dynamic-section' as FormFieldType,
                    maxItems: 8,
                    minItems: 0,
                    addButtonText: 'Add Key Feature',
                    removeButtonText: 'Remove',
                    itemTitle: 'Key Feature',
                    itemFields: [
                        {
                            id: 'keyFeature',
                            label: 'Key Feature',
                            type: 'input' as FormFieldType,
                            placeholder: 'Enter key feature',
                            validation: { required: true },
                            colSpan: 3,
                            compact: true,
                        },
                        {
                            id: 'icon',
                            label: 'Icon',
                            type: 'select' as FormFieldType,
                            placeholder: 'Select icon',
                            options: GLOBAL_TAGS_OPTIONS,
                            validation: { required: true },
                            colSpan: 1,
                            compact: true,
                        },
                    ],

                    validation: { required: false },
                    colSpan: 4,
                },
            ],
        },
        {
            id: 3,
            title: 'Product Resources',
            subtitle: 'Upload product documents',
            fields: [
                {
                    id: 'datasheetFile',
                    label: 'Upload Datasheet PDF',
                    type: 'file' as FormFieldType,
                    accept: FILE_UPLOAD_CONFIG.DOCUMENTS.accept,
                    multiple: false,
                    validation: {
                        required: false,
                        maxSize: FILE_UPLOAD_CONFIG.DOCUMENTS.maxSize,
                        allowedTypes: FILE_UPLOAD_CONFIG.DOCUMENTS.accept
                    },
                    colSpan: 2,
                },
                {
                    id: 'brochureFile',
                    label: 'Upload Brochure PDF',
                    type: 'file' as FormFieldType,
                    accept: FILE_UPLOAD_CONFIG.DOCUMENTS.accept,
                    multiple: false,
                    validation: {
                        required: false,
                        maxSize: FILE_UPLOAD_CONFIG.DOCUMENTS.maxSize,
                        allowedTypes: FILE_UPLOAD_CONFIG.DOCUMENTS.accept
                    },
                    colSpan: 2,
                },
                {
                    id: 'caseStudyFile',
                    label: 'Upload Case Study PDF',
                    type: 'file' as FormFieldType,
                    accept: FILE_UPLOAD_CONFIG.DOCUMENTS.accept,
                    multiple: false,
                    validation: {
                        required: false,
                        maxSize: FILE_UPLOAD_CONFIG.DOCUMENTS.maxSize,
                        allowedTypes: FILE_UPLOAD_CONFIG.DOCUMENTS.accept
                    },
                    colSpan: 4,
                },
            ],
        },
        {
            id: 4,
            title: 'Marketing Highlights',
            subtitle: 'Marketing selling points with visuals',
            fields: [
                {
                    id: 'marketingHighlights',
                    label: 'Marketing Highlights',
                    type: 'dynamic-section' as FormFieldType,
                    maxItems: 8,
                    minItems: 0,
                    addButtonText: 'Add Marketing Highlight',
                    removeButtonText: 'Remove',
                    itemTitle: 'Marketing Highlight',
                    itemFields: [
                        {
                            id: 'headline',
                            label: 'Headline',
                            type: 'input' as FormFieldType,
                            placeholder: 'Enter highlight headline (7-10 words)',
                            validation: { required: true },
                            colSpan: 4,
                            compact: true,
                        },
                        {
                            id: 'description',
                            label: 'Description',
                            type: 'textarea' as FormFieldType,
                            placeholder: 'Enter highlight description',
                            validation: { required: true },
                            colSpan: 4,
                            compact: true,
                        },
                        {
                            id: 'visuals',
                            label: 'Visuals / Illustrations',
                            type: 'file' as FormFieldType,
                            accept: FILE_UPLOAD_CONFIG.PRODUCT_PHOTOS.accept,
                            multiple: true,
                            maxFiles: FILE_UPLOAD_CONFIG.PRODUCT_PHOTOS.maxFiles,
                            validation: {
                                required: false,
                                maxFiles: FILE_UPLOAD_CONFIG.PRODUCT_PHOTOS.maxFiles,
                                maxSize: FILE_UPLOAD_CONFIG.PRODUCT_PHOTOS.maxSize,
                                allowedTypes: FILE_UPLOAD_CONFIG.PRODUCT_PHOTOS.accept
                            },
                            colSpan: 4,
                            onChange: (value: unknown) => {
                                const files = value as File[];
                                // Validate file uniqueness
                                const uniqueFiles = new Set(files.map(f => `${f.name}-${f.size}`));
                                if (uniqueFiles.size !== files.length) {
                                    throw new Error('Duplicate files detected. Please remove duplicates before uploading.');
                                }
                                return files;
                            }
                        },
                    ],
                    validation: { required: false },
                    colSpan: 4,
                },
            ],
        },
        {
            id: 5,
            title: 'Review & Submit',
            subtitle: 'Please review all information before submitting',
            fields: [
                {
                    id: 'review',
                    label: 'Review & Submit',
                    type: 'custom-component' as FormFieldType,
                    renderComponent: ReviewStep as React.ComponentType<BaseReviewStepProps<ProductFormData> & { onEditSection: (stepId: number | string) => void }>,
                    colSpan: 4
                },
            ],
        },
    ],
}; 