import { InputSanitizer } from './errorHandler';

// File type configurations
export const ALLOWED_FILE_TYPES = {
  images: [
    'image/jpeg',
    'image/jpg', 
    'image/png',
    'image/webp',
    'image/svg+xml',
    'image/gif'
  ],
  documents: [
    'application/pdf',
    'application/msword',
    'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
    'text/plain'
  ],
  archives: [
    'application/zip',
    'application/x-zip-compressed'
  ]
} as const;

// File size limits (in bytes)
export const FILE_SIZE_LIMITS = {
  image: 5 * 1024 * 1024,      // 5MB for images
  document: 10 * 1024 * 1024,  // 10MB for documents
  archive: 50 * 1024 * 1024,   // 50MB for archives
  default: 5 * 1024 * 1024     // 5MB default
} as const;

// Dangerous file extensions and MIME types
const DANGEROUS_EXTENSIONS = [
  '.exe', '.bat', '.cmd', '.com', '.pif', '.scr', '.vbs', '.js', '.jar',
  '.php', '.asp', '.aspx', '.jsp', '.py', '.rb', '.pl', '.sh', '.ps1'
];

const DANGEROUS_MIME_TYPES = [
  'application/x-executable',
  'application/x-msdownload',
  'application/x-msdos-program',
  'application/javascript',
  'text/javascript',
  'application/x-php',
  'application/x-httpd-php'
];

// Magic number signatures for file type validation
const FILE_SIGNATURES = {
  'image/jpeg': [0xFF, 0xD8, 0xFF],
  'image/png': [0x89, 0x50, 0x4E, 0x47],
  'image/gif': [0x47, 0x49, 0x46],
  'image/webp': [0x52, 0x49, 0x46, 0x46],
  'application/pdf': [0x25, 0x50, 0x44, 0x46],
  'application/zip': [0x50, 0x4B, 0x03, 0x04],
} as const;

export interface FileValidationResult {
  isValid: boolean;
  errors: string[];
  warnings: string[];
  sanitizedName?: string;
  detectedType?: string;
  securityScore: number; // 0-100, higher is safer
}

export interface FileUploadConfig {
  allowedTypes: string[];
  maxSize: number;
  allowExecutables: boolean;
  requireSignatureValidation: boolean;
  sanitizeFilenames: boolean;
  scanForMalware: boolean;
}

/**
 * Comprehensive file upload security utility
 */
export class FileUploadSecurity {
  /**
   * Validate file with comprehensive security checks
   */
  static async validateFile(
    file: File,
    config: Partial<FileUploadConfig> = {}
  ): Promise<FileValidationResult> {
    const defaultConfig: FileUploadConfig = {
      allowedTypes: [...ALLOWED_FILE_TYPES.images, ...ALLOWED_FILE_TYPES.documents],
      maxSize: FILE_SIZE_LIMITS.default,
      allowExecutables: false,
      requireSignatureValidation: true,
      sanitizeFilenames: true,
      scanForMalware: false,
      ...config
    };

    const result: FileValidationResult = {
      isValid: true,
      errors: [],
      warnings: [],
      securityScore: 100
    };

    // 1. Basic file validation
    await this.validateBasicProperties(file, defaultConfig, result);

    // 2. Filename security validation
    if (defaultConfig.sanitizeFilenames) {
      result.sanitizedName = this.sanitizeFilename(file.name);
    }

    // 3. MIME type validation
    await this.validateMimeType(file, defaultConfig, result);

    // 4. File signature validation
    if (defaultConfig.requireSignatureValidation) {
      await this.validateFileSignature(file, result);
    }

    // 5. Content security scanning
    await this.scanFileContent(file, result);

    // 6. Executable detection
    if (!defaultConfig.allowExecutables) {
      this.detectExecutables(file, result);
    }

    // 7. Calculate final security score
    this.calculateSecurityScore(result);

    // Final validation
    result.isValid = result.errors.length === 0 && result.securityScore >= 50;

    return result;
  }

  /**
   * Validate basic file properties
   */
  private static async validateBasicProperties(
    file: File,
    config: FileUploadConfig,
    result: FileValidationResult
  ): Promise<void> {
    // File size validation
    if (file.size > config.maxSize) {
      result.errors.push(
        `File size ${(file.size / 1024 / 1024).toFixed(2)}MB exceeds maximum allowed size of ${(config.maxSize / 1024 / 1024).toFixed(2)}MB`
      );
      result.securityScore -= 30;
    }

    // Empty file check
    if (file.size === 0) {
      result.errors.push('File is empty');
      result.securityScore -= 50;
    }

    // Extremely large file warning
    if (file.size > 100 * 1024 * 1024) { // 100MB
      result.warnings.push('File is very large and may impact performance');
      result.securityScore -= 10;
    }
  }

  /**
   * Sanitize filename to prevent path traversal and other attacks
   */
  static sanitizeFilename(filename: string): string {
    // Remove path separators and dangerous characters
    let sanitized = filename
      .replace(/[\/\\:*?"<>|]/g, '_')  // Replace dangerous characters
      .replace(/\.\./g, '_')           // Remove path traversal attempts
      .replace(/^\.+/, '')             // Remove leading dots
      .trim();

    // Ensure filename isn't empty
    if (!sanitized) {
      sanitized = 'file';
    }

    // Limit filename length
    if (sanitized.length > 255) {
      const ext = sanitized.substring(sanitized.lastIndexOf('.'));
      sanitized = sanitized.substring(0, 255 - ext.length) + ext;
    }

    // Add timestamp to prevent conflicts
    const timestamp = Date.now();
    const lastDot = sanitized.lastIndexOf('.');
    if (lastDot > 0) {
      sanitized = sanitized.substring(0, lastDot) + `_${timestamp}` + sanitized.substring(lastDot);
    } else {
      sanitized += `_${timestamp}`;
    }

    return sanitized;
  }

  /**
   * Validate MIME type against allowed types
   */
  private static async validateMimeType(
    file: File,
    config: FileUploadConfig,
    result: FileValidationResult
  ): Promise<void> {
    if (!config.allowedTypes.includes(file.type)) {
      result.errors.push(
        `File type ${file.type} is not allowed. Allowed types: ${config.allowedTypes.join(', ')}`
      );
      result.securityScore -= 40;
    }

    // Check for dangerous MIME types
    if (DANGEROUS_MIME_TYPES.includes(file.type)) {
      result.errors.push('File type is potentially dangerous');
      result.securityScore -= 60;
    }
  }

  /**
   * Validate file signature (magic numbers) to prevent MIME type spoofing
   */
  private static async validateFileSignature(
    file: File,
    result: FileValidationResult
  ): Promise<void> {
    try {
      const buffer = await file.slice(0, 16).arrayBuffer();
      const bytes = new Uint8Array(buffer);
      
      const expectedSignature = FILE_SIGNATURES[file.type as keyof typeof FILE_SIGNATURES];
      
      if (expectedSignature) {
        const matches = expectedSignature.every((byte, index) => bytes[index] === byte);
        
        if (!matches) {
          result.errors.push('File signature does not match declared type (possible spoofing attempt)');
          result.securityScore -= 50;
        } else {
          result.detectedType = file.type;
        }
      } else {
        result.warnings.push('File signature validation not available for this type');
        result.securityScore -= 5;
      }
    } catch (error) {
      result.warnings.push('Could not validate file signature');
      result.securityScore -= 10;
    }
  }

  /**
   * Scan file content for suspicious patterns
   */
  private static async scanFileContent(
    file: File,
    result: FileValidationResult
  ): Promise<void> {
    try {
      // For text-based files, scan content
      if (file.type.startsWith('text/') || file.type === 'application/javascript') {
        const text = await file.text();
        
        // Check for script injection patterns
        const suspiciousPatterns = [
          /<script\b[^<]*(?:(?!<\/script>)<[^<]*)*<\/script>/gi,
          /javascript:/gi,
          /vbscript:/gi,
          /onload\s*=/gi,
          /onerror\s*=/gi,
          /eval\s*\(/gi,
          /document\.write/gi,
          /innerHTML/gi
        ];

        for (const pattern of suspiciousPatterns) {
          if (pattern.test(text)) {
            result.warnings.push('File contains potentially suspicious script content');
            result.securityScore -= 20;
            break;
          }
        }
      }

      // For all files, check for embedded executables
      const buffer = await file.arrayBuffer();
      const bytes = new Uint8Array(buffer);
      
      // Check for PE header (Windows executable)
      if (this.containsExecutableSignature(bytes)) {
        result.errors.push('File contains executable code');
        result.securityScore -= 70;
      }

    } catch (error) {
      result.warnings.push('Could not scan file content');
      result.securityScore -= 5;
    }
  }

  /**
   * Detect executable files by extension and content
   */
  private static detectExecutables(
    file: File,
    result: FileValidationResult
  ): void {
    const filename = file.name.toLowerCase();
    
    for (const ext of DANGEROUS_EXTENSIONS) {
      if (filename.endsWith(ext)) {
        result.errors.push(`Executable file extension ${ext} is not allowed`);
        result.securityScore -= 60;
        break;
      }
    }
  }

  /**
   * Check for executable signatures in file content
   */
  private static containsExecutableSignature(bytes: Uint8Array): boolean {
    // PE header signature (Windows executables)
    if (bytes.length >= 64) {
      // Check for "MZ" signature at start
      if (bytes[0] === 0x4D && bytes[1] === 0x5A) {
        return true;
      }
    }

    // ELF header signature (Linux executables)
    if (bytes.length >= 4) {
      if (bytes[0] === 0x7F && bytes[1] === 0x45 && bytes[2] === 0x4C && bytes[3] === 0x46) {
        return true;
      }
    }

    return false;
  }

  /**
   * Calculate overall security score
   */
  private static calculateSecurityScore(result: FileValidationResult): void {
    // Additional penalties for multiple issues
    if (result.errors.length > 1) {
      result.securityScore -= result.errors.length * 5;
    }

    if (result.warnings.length > 2) {
      result.securityScore -= result.warnings.length * 2;
    }

    // Ensure score is within bounds
    result.securityScore = Math.max(0, Math.min(100, result.securityScore));
  }

  /**
   * Generate secure filename for storage
   */
  static generateSecureFilename(originalName: string, userId?: string): string {
    const sanitized = this.sanitizeFilename(originalName);
    const timestamp = Date.now();
    const random = Math.random().toString(36).substring(2, 8);
    const userPrefix = userId ? `${userId}_` : '';
    
    return `${userPrefix}${timestamp}_${random}_${sanitized}`;
  }

  /**
   * Validate file upload configuration
   */
  static validateUploadConfig(config: Partial<FileUploadConfig>): string[] {
    const errors: string[] = [];

    if (config.maxSize && config.maxSize > 100 * 1024 * 1024) {
      errors.push('Maximum file size should not exceed 100MB');
    }

    if (config.allowedTypes && config.allowedTypes.length === 0) {
      errors.push('At least one file type must be allowed');
    }

    if (config.allowExecutables) {
      errors.push('Allowing executable files is strongly discouraged');
    }

    return errors;
  }
}

/**
 * File upload rate limiting specifically for file operations
 */
export class FileUploadRateLimiter {
  private static uploadCounts = new Map<string, { count: number; resetTime: number }>();

  /**
   * Check if user can upload more files
   */
  static canUpload(identifier: string, maxUploads: number = 10, windowMs: number = 60000): boolean {
    const now = Date.now();
    const userLimit = this.uploadCounts.get(identifier);

    if (!userLimit || now > userLimit.resetTime) {
      this.uploadCounts.set(identifier, { count: 1, resetTime: now + windowMs });
      return true;
    }

    if (userLimit.count >= maxUploads) {
      return false;
    }

    userLimit.count++;
    return true;
  }

  /**
   * Get remaining upload quota
   */
  static getRemainingUploads(identifier: string, maxUploads: number = 10): number {
    const userLimit = this.uploadCounts.get(identifier);
    if (!userLimit || Date.now() > userLimit.resetTime) {
      return maxUploads;
    }
    return Math.max(0, maxUploads - userLimit.count);
  }
} 