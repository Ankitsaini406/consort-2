import { FirebaseError } from 'firebase/app';

export interface FormError {
    message: string;
    code?: string;
    field?: string;
    type: 'validation' | 'network' | 'firebase' | 'json' | 'unknown';
}

export class FormErrorHandler {
    /**
     * Handles Firebase-specific errors and returns user-friendly messages
     */
    static handleFirebaseError(error: FirebaseError): FormError {
        const errorMap: Record<string, string> = {
            'permission-denied': 'You do not have permission to perform this action.',
            'unavailable': 'Service is temporarily unavailable. Please try again later.',
            'deadline-exceeded': 'Request timed out. Please try again.',
            'resource-exhausted': 'Service is temporarily overloaded. Please try again later.',
            'unauthenticated': 'Authentication required. Please log in.',
            'not-found': 'The requested resource was not found.',
            'already-exists': 'This item already exists.',
            'invalid-argument': 'Invalid data provided. Please check your input.',
        };

        return {
            message: errorMap[error.code] || 'An unexpected error occurred. Please try again.',
            code: error.code,
            type: 'firebase'
        };
    }

    /**
     * Handles validation errors
     */
    static handleValidationError(field: string, message: string): FormError {
        return {
            message,
            field,
            type: 'validation'
        };
    }

    /**
     * Handles network-related errors
     */
    static handleNetworkError(error: Error): FormError {
        if (error.message.includes('Failed to fetch')) {
            return {
                message: 'Network connection failed. Please check your internet connection and try again.',
                type: 'network'
            };
        }

        return {
            message: 'Network error occurred. Please try again.',
            type: 'network'
        };
    }

    /**
     * Handles JSON parsing errors
     */
    static handleJSONError(error: Error): FormError {
        if (error.message.includes('Unexpected token') || 
            error.message.includes('JSON') || 
            error.message.includes('<!DOCTYPE')) {
            return {
                message: 'Invalid response format received. Please try again or contact support.',
                type: 'json'
            };
        }

        return {
            message: 'Data parsing error occurred. Please try again.',
            type: 'json'
        };
    }

    /**
     * Generic error handler that determines error type and routes to appropriate handler
     */
    static handleError(error: unknown): FormError {
        // Handle null/undefined errors
        if (!error) {
            return {
                message: 'An unknown error occurred. Please try again.',
                type: 'unknown'
            };
        }

        // Firebase error
        if (error && typeof error === 'object' && 'code' in error) {
            return this.handleFirebaseError(error as FirebaseError);
        }

        // Handle Error objects
        if (error instanceof Error) {
            // JSON parsing errors
            if (error.message.includes('Unexpected token') || 
                error.message.includes('JSON') || 
                error.message.includes('<!DOCTYPE')) {
                return this.handleJSONError(error);
            }

            // Network errors
            if (error.message.includes('fetch') || 
                error.message.includes('network') || 
                error.message.includes('connection')) {
                return this.handleNetworkError(error);
            }

            // Rate limiting errors
            if (error.message.includes('Rate limit exceeded')) {
                return {
                    message: error.message,
                    type: 'validation'
                };
            }

            // Generic error
            return {
                message: error.message || 'An unexpected error occurred.',
                type: 'unknown'
            };
        }

        // Handle string errors
        if (typeof error === 'string') {
            return {
                message: error,
                type: 'unknown'
            };
        }

        // Unknown error type
        return {
            message: 'An unexpected error occurred. Please try again.',
            type: 'unknown'
        };
    }

    /**
     * Logs errors for debugging and monitoring
     */
    static logError(error: unknown, context: string = 'Unknown'): void {
        const timestamp = new Date().toISOString();
        const errorInfo = {
            timestamp,
            context,
            error: error instanceof Error ? {
                name: error.name,
                message: error.message,
                stack: error.stack
            } : error,
            userAgent: typeof window !== 'undefined' ? window.navigator.userAgent : 'Server',
            url: typeof window !== 'undefined' ? window.location.href : 'Server'
        };

        console.error(`[${context}] Error logged:`, errorInfo);

        // In production, you might want to send this to a logging service
        // Example: sendToLoggingService(errorInfo);
    }
}

/**
 * User notification utility for consistent error/success messaging
 */
export class UserNotification {
    static showError(error: FormError | string): void {
        const message = typeof error === 'string' ? error : error.message;
        console.error('User Error:', message);
        
        // In a real app, you might use a toast library or notification system
        // For now, we'll use console and could integrate with a UI notification system
        if (typeof window !== 'undefined') {
            // You could integrate with react-hot-toast, react-toastify, or similar
            alert(`Error: ${message}`);
        }
    }

    static showSuccess(message: string): void {
        console.log('Success:', message);
        
        // In a real app, you might use a toast library
        if (typeof window !== 'undefined') {
            // You could integrate with react-hot-toast, react-toastify, or similar
            alert(`Success: ${message}`);
        }
    }

    static showWarning(message: string): void {
        console.warn('Warning:', message);
        
        if (typeof window !== 'undefined') {
            alert(`Warning: ${message}`);
        }
    }
}

/**
 * Input sanitization utilities
 */
export class InputSanitizer {
    /**
     * Sanitize string input to prevent XSS
     */
    static sanitizeString(input: string): string {
        if (!input || typeof input !== 'string') return '';
        
        return input
            .replace(/[<>]/g, '') // Remove < and > characters
            .replace(/javascript:/gi, '') // Remove javascript: protocol
            .replace(/on\w+=/gi, '') // Remove event handlers
            .trim();
    }

    /**
     * Sanitize HTML content (basic sanitization)
     */
    static sanitizeHTML(input: string): string {
        if (!input || typeof input !== 'string') return '';
        
        return input
            .replace(/<script\b[^<]*(?:(?!<\/script>)<[^<]*)*<\/script>/gi, '') // Remove script tags
            .replace(/<iframe\b[^<]*(?:(?!<\/iframe>)<[^<]*)*<\/iframe>/gi, '') // Remove iframe tags
            .replace(/javascript:/gi, '') // Remove javascript: protocol
            .replace(/on\w+=/gi, '') // Remove event handlers
            .trim();
    }

    /**
     * Sanitize file names
     */
    static sanitizeFileName(fileName: string): string {
        if (!fileName || typeof fileName !== 'string') return '';
        
        return fileName
            .replace(/[^a-zA-Z0-9._-]/g, '_') // Replace special characters with underscore
            .replace(/_{2,}/g, '_') // Replace multiple underscores with single
            .substring(0, 255); // Limit length
    }

    /**
     * Validates and sanitizes file uploads
     */
    static validateFile(file: File, allowedTypes: string[], maxSize: number): { isValid: boolean; error?: string } {
        // Check file type
        if (!allowedTypes.includes(file.type)) {
            return {
                isValid: false,
                error: `File type ${file.type} is not allowed. Allowed types: ${allowedTypes.join(', ')}`
            };
        }

        // Check file size
        if (file.size > maxSize) {
            return {
                isValid: false,
                error: `File size ${(file.size / 1024 / 1024).toFixed(2)}MB exceeds maximum allowed size of ${(maxSize / 1024 / 1024).toFixed(2)}MB`
            };
        }

        return { isValid: true };
    }
} 