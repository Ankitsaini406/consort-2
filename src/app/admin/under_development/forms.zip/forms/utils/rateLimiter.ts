import { Ratelimit } from "@upstash/ratelimit";
import { Redis } from "@upstash/redis";

// Check if Redis is properly configured
const isRedisConfigured = () => {
  return !!(process.env.UPSTASH_REDIS_REST_URL && process.env.UPSTASH_REDIS_REST_TOKEN);
};

// Initialize Redis client only if configured
const redis = isRedisConfigured() ? new Redis({
  url: process.env.UPSTASH_REDIS_REST_URL!,
  token: process.env.UPSTASH_REDIS_REST_TOKEN!,
}) : null;

// Rate limiting configurations for different form types
export const rateLimitConfigs = isRedisConfigured() ? {
  // General form submission - 5 submissions per minute
  formSubmission: new Ratelimit({
    redis: redis!,
    limiter: Ratelimit.slidingWindow(5, "1 m"),
    analytics: true,
    prefix: "form_submission",
  }),
  
  // File upload - 3 uploads per minute (more restrictive due to resource usage)
  fileUpload: new Ratelimit({
    redis: redis!,
    limiter: Ratelimit.slidingWindow(3, "1 m"),
    analytics: true,
    prefix: "file_upload",
  }),
  
  // Admin actions - 10 actions per minute
  adminAction: new Ratelimit({
    redis: redis!,
    limiter: Ratelimit.slidingWindow(10, "1 m"),
    analytics: true,
    prefix: "admin_action",
  }),
  
  // Strict rate limiting for suspicious activity - 2 per minute
  strict: new Ratelimit({
    redis: redis!,
    limiter: Ratelimit.slidingWindow(2, "1 m"),
    analytics: true,
    prefix: "strict_limit",
  }),
} : null;

export type RateLimitType = 'formSubmission' | 'fileUpload' | 'adminAction' | 'strict';

export interface RateLimitResult {
  success: boolean;
  limit: number;
  remaining: number;
  reset: Date;
  error?: string;
}

/**
 * Rate limiting utility class
 */
export class RateLimiter {
  /**
   * Check rate limit for a specific identifier and limit type
   */
  static async checkLimit(
    identifier: string,
    limitType: RateLimitType = 'formSubmission'
  ): Promise<RateLimitResult> {
    // If Redis is not configured, allow all requests
    if (!isRedisConfigured() || !rateLimitConfigs) {
      console.warn('Rate limiting disabled: Redis not configured');
      return {
        success: true,
        limit: 999,
        remaining: 999,
        reset: new Date(Date.now() + 60000), // 1 minute from now
        error: 'Rate limiting disabled - Redis not configured',
      };
    }

    try {
      const ratelimit = rateLimitConfigs[limitType];
      const result = await ratelimit.limit(identifier);
      
      return {
        success: result.success,
        limit: result.limit,
        remaining: result.remaining,
        reset: new Date(result.reset),
      };
    } catch (error) {
      console.error('Rate limiting error:', error);
      // In case of Redis failure, allow the request but log the error
      return {
        success: true,
        limit: 0,
        remaining: 0,
        reset: new Date(),
        error: 'Rate limiting service unavailable',
      };
    }
  }

  /**
   * Get client identifier from request (IP address, user ID, etc.)
   */
  static getClientIdentifier(request?: Request): string {
    if (typeof window !== 'undefined') {
      // Client-side: use a combination of factors
      return `client_${this.generateClientFingerprint()}`;
    }
    
    if (request) {
      // Server-side: use IP address
      const forwarded = request.headers.get('x-forwarded-for');
      const ip = forwarded ? forwarded.split(',')[0] : 
                 request.headers.get('x-real-ip') || 
                 'unknown';
      return `ip_${ip}`;
    }
    
    return 'unknown_client';
  }

  /**
   * Generate a client fingerprint for browser-based identification
   */
  private static generateClientFingerprint(): string {
    if (typeof window === 'undefined') return 'server';
    
    try {
      const canvas = document.createElement('canvas');
      const ctx = canvas.getContext('2d');
      if (ctx) {
        ctx.textBaseline = 'top';
        ctx.font = '14px Arial';
        ctx.fillText('Rate limiting fingerprint', 2, 2);
      }
      
      const fingerprint = [
        navigator.userAgent,
        navigator.language,
        screen.width + 'x' + screen.height,
        new Date().getTimezoneOffset(),
        canvas.toDataURL(),
      ].join('|');
      
      // Simple hash function
      let hash = 0;
      for (let i = 0; i < fingerprint.length; i++) {
        const char = fingerprint.charCodeAt(i);
        hash = ((hash << 5) - hash) + char;
        hash = hash & hash; // Convert to 32-bit integer
      }
      
      return Math.abs(hash).toString(36);
    } catch (error) {
      console.warn('Failed to generate client fingerprint:', error);
      return 'fallback_' + Math.random().toString(36).substring(2, 15);
    }
  }

  /**
   * Check if rate limiting is properly configured
   */
  static isConfigured(): boolean {
    return isRedisConfigured();
  }

  /**
   * Get rate limit status for display to user
   */
  static formatRateLimitMessage(result: RateLimitResult): string {
    if (result.success) {
      return `${result.remaining} requests remaining`;
    }
    
    const resetTime = result.reset.toLocaleTimeString();
    return `Rate limit exceeded. Try again after ${resetTime}`;
  }
}

/**
 * Rate limiting middleware for form submissions
 */
export async function withRateLimit<T>(
  identifier: string,
  limitType: RateLimitType,
  operation: () => Promise<T>
): Promise<T> {
  try {
    const rateLimitResult = await RateLimiter.checkLimit(identifier, limitType);
    
    if (!rateLimitResult.success) {
      const message = RateLimiter.formatRateLimitMessage(rateLimitResult);
      throw new Error(`Rate limit exceeded: ${message}`);
    }
    
    // Log rate limit status for monitoring
    if (RateLimiter.isConfigured()) {
      console.log(`Rate limit check passed for ${identifier}: ${rateLimitResult.remaining}/${rateLimitResult.limit} remaining`);
    }
    
    return await operation();
  } catch (error) {
    // If rate limiting fails, still allow the operation but log the error
    if (error instanceof Error && error.message.includes('Rate limit exceeded')) {
      throw error; // Re-throw rate limit errors
    }
    
    console.warn('Rate limiting check failed, allowing operation:', error);
    return await operation();
  }
}

/**
 * Enhanced rate limiting with progressive penalties
 */
export class ProgressiveRateLimiter {
  /**
   * Apply progressive rate limiting based on violation history
   */
  static async checkWithProgression(
    identifier: string,
    baseType: RateLimitType = 'formSubmission'
  ): Promise<RateLimitResult> {
    // If Redis is not configured, fall back to basic rate limiting
    if (!isRedisConfigured() || !redis) {
      return RateLimiter.checkLimit(identifier, baseType);
    }

    try {
      // Check violation history
      const violationKey = `violations_${identifier}`;
      const violations = await redis.get(violationKey) as number || 0;
      
      let limitType: RateLimitType = baseType;
      
      // Apply stricter limits based on violation history
      if (violations >= 3) {
        limitType = 'strict';
      }
      
      const result = await RateLimiter.checkLimit(identifier, limitType);
      
      // Track violations
      if (!result.success) {
        await redis.incr(violationKey);
        await redis.expire(violationKey, 3600); // Reset violations after 1 hour
      }
      
      return result;
    } catch (error) {
      console.warn('Progressive rate limiting failed, falling back to basic:', error);
      return RateLimiter.checkLimit(identifier, baseType);
    }
  }
} 