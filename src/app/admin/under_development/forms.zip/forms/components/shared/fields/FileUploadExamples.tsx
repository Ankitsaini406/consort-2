import React, { useState } from 'react';
import { FeatherUploadCloud, FeatherCheckCircle, FeatherTrash, FeatherFile, FeatherImage, FeatherFileText } from "@subframe/core";
import { FormLabel } from './FormLabel';

// Common props for all examples
interface FileUploadExampleProps {
    id: string;
    label: string;
    accept?: string;
    multiple?: boolean;
    maxFiles?: number;
    required?: boolean;
}

// Option 1: Drag & Drop Zone with Visual Feedback
export const DragDropFileUpload: React.FC<FileUploadExampleProps> = ({
    id, label, accept, multiple = false, maxFiles = 1, required = false
}) => {
    const [files, setFiles] = useState<File[]>([]);
    const [isDragging, setIsDragging] = useState(false);

    const handleDragOver = (e: React.DragEvent) => {
        e.preventDefault();
        setIsDragging(true);
    };

    const handleDragLeave = () => setIsDragging(false);

    const handleDrop = (e: React.DragEvent) => {
        e.preventDefault();
        setIsDragging(false);
        const droppedFiles = Array.from(e.dataTransfer.files);
        setFiles(multiple ? droppedFiles.slice(0, maxFiles) : [droppedFiles[0]]);
    };

    const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
        if (e.target.files) {
            const selectedFiles = Array.from(e.target.files);
            setFiles(multiple ? selectedFiles.slice(0, maxFiles) : [selectedFiles[0]]);
        }
    };

    return (
        <div className="flex flex-col gap-2 w-full">
            <FormLabel htmlFor={id} required={required}>{label}</FormLabel>
            
            <div
                className={`relative border-2 border-dashed rounded-lg p-8 text-center transition-all duration-200 ${
                    isDragging 
                        ? 'border-brand-500 bg-brand-50' 
                        : 'border-neutral-300 hover:border-brand-400 hover:bg-neutral-50'
                }`}
                onDragOver={handleDragOver}
                onDragLeave={handleDragLeave}
                onDrop={handleDrop}
            >
                <input
                    type="file"
                    id={id}
                    accept={accept}
                    multiple={multiple}
                    onChange={handleFileSelect}
                    className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
                />
                
                <div className="flex flex-col items-center gap-3">
                    <FeatherUploadCloud className="w-12 h-12 text-neutral-400" />
                    <div>
                        <p className="text-sm font-medium text-neutral-700">
                            Drag files here or <span className="text-brand-600">click to browse</span>
                        </p>
                        <p className="text-xs text-neutral-500 mt-1">
                            {accept ? `Supports: ${accept}` : 'All file types supported'}
                        </p>
                    </div>
                </div>
            </div>

            {files.length > 0 && (
                <div className="space-y-2">
                    {files.map((file, index) => (
                        <div key={index} className="flex items-center gap-3 p-3 bg-neutral-50 rounded-md">
                            <FeatherCheckCircle className="w-5 h-5 text-green-500" />
                            <span className="flex-1 text-sm text-neutral-700">{file.name}</span>
                            <span className="text-xs text-neutral-500">{(file.size / 1024).toFixed(1)} KB</span>
                            <button
                                onClick={() => setFiles(files.filter((_, i) => i !== index))}
                                className="p-1 hover:bg-neutral-200 rounded"
                            >
                                <FeatherTrash className="w-4 h-4 text-red-500" />
                            </button>
                        </div>
                    ))}
                </div>
            )}
        </div>
    );
};

// Option 2: Card-Style Upload with Preview
export const CardStyleFileUpload: React.FC<FileUploadExampleProps> = ({
    id, label, accept, multiple = false, maxFiles = 1, required = false
}) => {
    const [files, setFiles] = useState<File[]>([]);

    const getFileIcon = (fileName: string) => {
        const ext = fileName.split('.').pop()?.toLowerCase();
        if (['jpg', 'jpeg', 'png', 'gif', 'webp'].includes(ext || '')) {
            return <FeatherImage className="w-8 h-8 text-blue-500" />;
        }
        if (ext === 'pdf') {
            return <FeatherFileText className="w-8 h-8 text-red-500" />;
        }
        return <FeatherFile className="w-8 h-8 text-neutral-500" />;
    };

    const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
        if (e.target.files) {
            const selectedFiles = Array.from(e.target.files);
            setFiles(multiple ? selectedFiles.slice(0, maxFiles) : [selectedFiles[0]]);
        }
    };

    return (
        <div className="flex flex-col gap-3 w-full">
            <FormLabel htmlFor={id} required={required}>{label}</FormLabel>
            
            <div className="border border-neutral-200 rounded-lg overflow-hidden">
                <div className="bg-neutral-50 p-4 border-b">
                    <input
                        type="file"
                        id={id}
                        accept={accept}
                        multiple={multiple}
                        onChange={handleFileSelect}
                        className="hidden"
                    />
                    <label
                        htmlFor={id}
                        className="flex items-center justify-center gap-2 p-3 bg-white border border-neutral-300 rounded-md cursor-pointer hover:bg-neutral-50 transition-colors"
                    >
                        <FeatherUploadCloud className="w-5 h-5 text-brand-600" />
                        <span className="text-sm font-medium text-brand-600">Choose Files</span>
                    </label>
                </div>
                
                {files.length > 0 ? (
                    <div className="p-4 space-y-3">
                        {files.map((file, index) => (
                            <div key={index} className="flex items-center gap-3 p-3 bg-white border border-neutral-200 rounded-md">
                                {getFileIcon(file.name)}
                                <div className="flex-1">
                                    <p className="text-sm font-medium text-neutral-700">{file.name}</p>
                                    <p className="text-xs text-neutral-500">{(file.size / 1024).toFixed(1)} KB</p>
                                </div>
                                <button
                                    onClick={() => setFiles(files.filter((_, i) => i !== index))}
                                    className="p-2 hover:bg-red-50 rounded-md transition-colors"
                                >
                                    <FeatherTrash className="w-4 h-4 text-red-500" />
                                </button>
                            </div>
                        ))}
                    </div>
                ) : (
                    <div className="p-6 text-center text-neutral-500">
                        <p className="text-sm">No files selected</p>
                    </div>
                )}
            </div>
        </div>
    );
};

// Option 3: Compact Inline Upload
export const CompactFileUpload: React.FC<FileUploadExampleProps> = ({
    id, label, accept, multiple = false, maxFiles = 1, required = false
}) => {
    const [files, setFiles] = useState<File[]>([]);
    const [isExpanded, setIsExpanded] = useState(false);

    const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
        if (e.target.files) {
            const selectedFiles = Array.from(e.target.files);
            setFiles(multiple ? selectedFiles.slice(0, maxFiles) : [selectedFiles[0]]);
            setIsExpanded(true);
        }
    };

    return (
        <div className="flex flex-col gap-2 w-full">
            <FormLabel htmlFor={id} required={required}>{label}</FormLabel>
            
            <div className="flex items-center gap-2">
                <input
                    type="file"
                    id={id}
                    accept={accept}
                    multiple={multiple}
                    onChange={handleFileSelect}
                    className="hidden"
                />
                <label
                    htmlFor={id}
                    className="inline-flex items-center gap-2 px-3 py-2 bg-brand-600 text-white text-sm font-medium rounded-md cursor-pointer hover:bg-brand-700 transition-colors"
                >
                    <FeatherUploadCloud className="w-4 h-4" />
                    Upload
                    {files.length > 0 && (
                        <span className="bg-brand-500 text-xs px-2 py-0.5 rounded-full">
                            {files.length}
                        </span>
                    )}
                </label>
                
                {files.length > 0 && (
                    <button
                        onClick={() => setIsExpanded(!isExpanded)}
                        className="text-sm text-brand-600 hover:text-brand-700"
                    >
                        {isExpanded ? 'Hide' : 'Show'} files
                    </button>
                )}
            </div>

            {isExpanded && files.length > 0 && (
                <div className="mt-2 space-y-1">
                    {files.map((file, index) => (
                        <div key={index} className="flex items-center gap-2 p-2 bg-neutral-50 rounded text-sm">
                            <FeatherCheckCircle className="w-4 h-4 text-green-500" />
                            <span className="flex-1 truncate">{file.name}</span>
                            <button
                                onClick={() => setFiles(files.filter((_, i) => i !== index))}
                                className="p-1 hover:bg-neutral-200 rounded"
                            >
                                <FeatherTrash className="w-3 h-3 text-red-500" />
                            </button>
                        </div>
                    ))}
                </div>
            )}
        </div>
    );
};

// Option 4: Modern Upload with Progress (Simulated)
export const ModernFileUpload: React.FC<FileUploadExampleProps> = ({
    id, label, accept, multiple = false, maxFiles = 1, required = false
}) => {
    const [files, setFiles] = useState<Array<{ file: File; progress: number; status: 'uploading' | 'complete' | 'error' }>>([]);

    const simulateUpload = (file: File) => {
        const fileWithProgress = { file, progress: 0, status: 'uploading' as const };
        setFiles(prev => [...prev, fileWithProgress]);

        // Simulate upload progress
        const interval = setInterval(() => {
            setFiles(prev => prev.map(f => 
                f.file === file 
                    ? { ...f, progress: Math.min(f.progress + 10, 100) }
                    : f
            ));
        }, 100);

        setTimeout(() => {
            clearInterval(interval);
            setFiles(prev => prev.map(f => 
                f.file === file 
                    ? { ...f, progress: 100, status: 'complete' }
                    : f
            ));
        }, 1000);
    };

    const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
        if (e.target.files) {
            const selectedFiles = Array.from(e.target.files);
            const filesToAdd = multiple ? selectedFiles.slice(0, maxFiles) : [selectedFiles[0]];
            filesToAdd.forEach(simulateUpload);
        }
    };

    return (
        <div className="flex flex-col gap-3 w-full">
            <FormLabel htmlFor={id} required={required}>{label}</FormLabel>
            
            <div className="border-2 border-dashed border-neutral-300 rounded-lg p-6 text-center hover:border-brand-400 transition-colors">
                <input
                    type="file"
                    id={id}
                    accept={accept}
                    multiple={multiple}
                    onChange={handleFileSelect}
                    className="hidden"
                />
                <label htmlFor={id} className="cursor-pointer">
                    <div className="flex flex-col items-center gap-2">
                        <div className="w-12 h-12 bg-brand-100 rounded-full flex items-center justify-center">
                            <FeatherUploadCloud className="w-6 h-6 text-brand-600" />
                        </div>
                        <div>
                            <p className="text-sm font-medium text-neutral-700">Upload files</p>
                            <p className="text-xs text-neutral-500">Drag and drop or click to browse</p>
                        </div>
                    </div>
                </label>
            </div>

            {files.length > 0 && (
                <div className="space-y-3">
                    {files.map((fileItem, index) => (
                        <div key={index} className="p-3 border border-neutral-200 rounded-lg">
                            <div className="flex items-center gap-3 mb-2">
                                {getFileIcon(fileItem.file.name)}
                                <div className="flex-1">
                                    <p className="text-sm font-medium text-neutral-700">{fileItem.file.name}</p>
                                    <p className="text-xs text-neutral-500">{(fileItem.file.size / 1024).toFixed(1)} KB</p>
                                </div>
                                {fileItem.status === 'complete' && (
                                    <button
                                        onClick={() => setFiles(files.filter((_, i) => i !== index))}
                                        className="p-1 hover:bg-neutral-100 rounded"
                                    >
                                        <FeatherTrash className="w-4 h-4 text-red-500" />
                                    </button>
                                )}
                            </div>
                            
                            {fileItem.status === 'uploading' && (
                                <div className="w-full bg-neutral-200 rounded-full h-2">
                                    <div 
                                        className="bg-brand-600 h-2 rounded-full transition-all duration-300"
                                        style={{ width: `${fileItem.progress}%` }}
                                    />
                                </div>
                            )}
                            
                            {fileItem.status === 'complete' && (
                                <div className="flex items-center gap-1 text-green-600">
                                    <FeatherCheckCircle className="w-4 h-4" />
                                    <span className="text-xs">Upload complete</span>
                                </div>
                            )}
                        </div>
                    ))}
                </div>
            )}
        </div>
    );

    function getFileIcon(fileName: string) {
        const ext = fileName.split('.').pop()?.toLowerCase();
        if (['jpg', 'jpeg', 'png', 'gif', 'webp'].includes(ext || '')) {
            return <FeatherImage className="w-5 h-5 text-blue-500" />;
        }
        if (ext === 'pdf') {
            return <FeatherFileText className="w-5 h-5 text-red-500" />;
        }
        return <FeatherFile className="w-5 h-5 text-neutral-500" />;
    }
};

// Option 5: Enhanced Current Design
export const EnhancedCurrentFileUpload: React.FC<FileUploadExampleProps> = ({
    id, label, accept, multiple = false, maxFiles = 1, required = false
}) => {
    const [files, setFiles] = useState<File[]>([]);

    const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
        if (e.target.files) {
            const selectedFiles = Array.from(e.target.files);
            setFiles(multiple ? selectedFiles.slice(0, maxFiles) : [selectedFiles[0]]);
        }
    };

    const getFileTypeInfo = (fileName: string) => {
        const ext = fileName.split('.').pop()?.toLowerCase();
        if (['jpg', 'jpeg', 'png', 'gif', 'webp'].includes(ext || '')) {
            return { icon: <FeatherImage className="w-5 h-5 text-blue-500" />, type: 'Image' };
        }
        if (ext === 'pdf') {
            return { icon: <FeatherFileText className="w-5 h-5 text-red-500" />, type: 'PDF' };
        }
        return { icon: <FeatherFile className="w-5 h-5 text-neutral-500" />, type: 'File' };
    };

    return (
        <div className="flex flex-col gap-3 w-full">
            <FormLabel htmlFor={id} required={required}>{label}</FormLabel>
            
            <div className="border border-neutral-300 rounded-lg p-4 bg-gradient-to-br from-brand-25 to-brand-50">
                <input
                    type="file"
                    id={id}
                    accept={accept}
                    multiple={multiple}
                    onChange={handleFileSelect}
                    className="hidden"
                />
                <label
                    htmlFor={id}
                    className="flex flex-col items-center gap-3 p-4 cursor-pointer hover:bg-brand-100 rounded-lg transition-colors"
                >
                    <div className="w-10 h-10 bg-brand-600 rounded-full flex items-center justify-center">
                        <FeatherUploadCloud className="w-5 h-5 text-white" />
                    </div>
                    <div className="text-center">
                        <p className="text-sm font-medium text-brand-700">Click to Upload</p>
                        <p className="text-xs text-brand-600 mt-1">
                            {accept ? `Accepts: ${accept}` : 'All file types'}
                        </p>
                    </div>
                </label>
            </div>

            {files.length > 0 && (
                <div className="space-y-2">
                    {files.map((file, index) => {
                        const fileInfo = getFileTypeInfo(file.name);
                        return (
                            <div key={index} className="flex items-center gap-3 p-3 bg-white border border-neutral-200 rounded-lg shadow-sm">
                                <div className="flex items-center gap-2">
                                    {fileInfo.icon}
                                    <span className="text-xs text-neutral-500 font-medium">{fileInfo.type}</span>
                                </div>
                                <div className="flex-1">
                                    <p className="text-sm font-medium text-neutral-700">{file.name}</p>
                                    <p className="text-xs text-neutral-500">{(file.size / 1024).toFixed(1)} KB</p>
                                </div>
                                <div className="flex items-center gap-2">
                                    <FeatherCheckCircle className="w-4 h-4 text-green-500" />
                                    <button
                                        onClick={() => setFiles(files.filter((_, i) => i !== index))}
                                        className="p-1.5 hover:bg-red-50 rounded-md transition-colors"
                                    >
                                        <FeatherTrash className="w-4 h-4 text-red-500" />
                                    </button>
                                </div>
                            </div>
                        );
                    })}
                </div>
            )}
        </div>
    );
};

// Demo component to showcase all options
export const FileUploadShowcase: React.FC = () => {
    return (
        <div className="max-w-4xl mx-auto p-6 space-y-8">
            <h1 className="text-2xl font-bold text-neutral-800 mb-8">File Upload Design Options</h1>
            
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                <div className="space-y-4">
                    <h2 className="text-lg font-semibold text-neutral-700">Option 1: Drag & Drop Zone</h2>
                    <DragDropFileUpload 
                        id="drag-drop" 
                        label="Upload Files" 
                        accept=".pdf,.jpg,.png" 
                        multiple={true} 
                        required={true}
                    />
                </div>

                <div className="space-y-4">
                    <h2 className="text-lg font-semibold text-neutral-700">Option 2: Card-Style Upload</h2>
                    <CardStyleFileUpload 
                        id="card-style" 
                        label="Upload Document" 
                        accept=".pdf" 
                        required={true}
                    />
                </div>

                <div className="space-y-4">
                    <h2 className="text-lg font-semibold text-neutral-700">Option 3: Compact Inline</h2>
                    <CompactFileUpload 
                        id="compact" 
                        label="Attach Files" 
                        accept=".pdf,.doc,.docx" 
                        multiple={true}
                        required={true}
                    />
                </div>

                <div className="space-y-4">
                    <h2 className="text-lg font-semibold text-neutral-700">Option 4: Modern with Progress</h2>
                    <ModernFileUpload 
                        id="modern" 
                        label="Upload Images" 
                        accept="image/*" 
                        multiple={true}
                        required={true}
                    />
                </div>

                <div className="space-y-4 lg:col-span-2">
                    <h2 className="text-lg font-semibold text-neutral-700">Option 5: Enhanced Current Design</h2>
                    <EnhancedCurrentFileUpload 
                        id="enhanced" 
                        label="Upload Brochure" 
                        accept=".pdf" 
                        required={true}
                    />
                </div>
            </div>
        </div>
    );
}; 