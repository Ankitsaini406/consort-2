import React from 'react';
import { Button3 } from "@/ui/components/Button3";

interface UniversalFormActionsProps {
    currentStep: number;
    totalSteps: number;
    isSubmitting: boolean;
    isCurrentStepValid: boolean;
    onPrevious: () => void;
    onNext: () => void;
    onSubmit: (isDraft?: boolean) => void;
    submitText?: string; // Customizable submit button text
}

export const UniversalFormActions: React.FC<UniversalFormActionsProps> = ({ 
    currentStep, 
    totalSteps, 
    onPrevious, 
    onNext, 
    onSubmit, 
    isSubmitting, 
    isCurrentStepValid,
    submitText = "Submit" // Default text
}) => (
    <div className="flex justify-between pt-6 mt-auto border-t border-neutral-border flex-shrink-0">
        <Button3
            variant="neutral-tertiary"
            onClick={onPrevious}
            disabled={currentStep === 0 || isSubmitting}
        >
            Previous
        </Button3>

        {currentStep < totalSteps - 1 ? (
            <Button3
                variant="brand-primary"
                onClick={onNext}
                disabled={isSubmitting || !isCurrentStepValid}
            >
                Next
            </Button3>
        ) : (
            <Button3
                variant="brand-primary"
                onClick={() => onSubmit()} 
                disabled={isSubmitting || !isCurrentStepValid}
            >
                {isSubmitting ? 'Submitting...' : submitText}
            </Button3>
        )}
    </div>
); 