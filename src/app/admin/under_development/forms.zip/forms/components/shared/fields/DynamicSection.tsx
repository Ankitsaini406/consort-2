'use client';

import React, { useState, useEffect } from 'react';
import { FeatherPlus, FeatherX } from "@subframe/core";
import { Button3 } from "@/ui/components/Button3";
import { FormInput } from './FormInput';
import { FormTextArea } from './FormTextArea';
import { FormFileUpload } from './FormFileUpload';
import { FormLabel } from './FormLabel';
import { Select, SelectContent, SelectGroup, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { MultiSelector, MultiSelectorContent, MultiSelectorInput, MultiSelectorItem, MultiSelectorList, MultiSelectorTrigger } from "@/components/ui/multi-select";
import { FormField, FormFieldType, CustomArrayFieldProps } from '@/app/admin/forms/types';

interface DynamicSectionProps extends CustomArrayFieldProps<Record<string, unknown>> {
    field: FormField;
}

function cn(...classes: (string | undefined | null | boolean)[]) {
    return classes.filter(Boolean).join(' ');
}

export const DynamicSection: React.FC<DynamicSectionProps> = ({
    field,
    items = [],
    addItem,
    removeItem,
    updateItem,
    error,
    formData
}) => {
    const {
        itemFields = [],
        maxItems = 10,
        minItems = 0,
        addButtonText = "Add Item",
        removeButtonText = "Remove",
        itemTitle = "Item"
    } = field;

    const [newlyAddedIndex, setNewlyAddedIndex] = useState<number | null>(null);

    const handleAddItem = () => {
        if (items.length >= maxItems) return;
        
        // Create default values for new item based on itemFields
        const defaultItem: Record<string, unknown> = {};
        itemFields.forEach(itemField => {
            defaultItem[itemField.id] = itemField.defaultValue || '';
        });
        
        const newIndex = items.length;
        addItem(defaultItem);
        
        // Set the newly added index for animation
        setNewlyAddedIndex(newIndex);
        
        // Clear the animation after 1 second
        setTimeout(() => {
            setNewlyAddedIndex(null);
        }, 1000);
    };

    const handleUpdateField = (itemIndex: number, fieldId: string, value: unknown) => {
        updateItem(itemIndex, (currentItem: Record<string, unknown>) => ({
            ...currentItem,
            [fieldId]: value
        }));
    };

    const renderField = (itemField: FormField, itemIndex: number, itemValue: Record<string, unknown>) => {
        const fieldValue = itemValue[itemField.id];
        const fieldId = `${field.id}-${itemIndex}-${itemField.id}`;

        const commonProps = {
            id: fieldId,
            label: itemField.label,
            placeholder: itemField.placeholder,
            required: itemField.validation?.required,
            className: itemField.className,
            compact: itemField.compact
        };

        switch (itemField.type) {
            case 'input':
                return (
                    <FormInput
                        {...commonProps}
                        type="text"
                        value={fieldValue as string || ''}
                        onChange={(val: string) => handleUpdateField(itemIndex, itemField.id, val)}
                    />
                );
            
            case 'textarea':
                return (
                    <FormTextArea
                        {...commonProps}
                        value={fieldValue as string || ''}
                        onChange={(val: string) => handleUpdateField(itemIndex, itemField.id, val)}
                    />
                );
            
            case 'file':
                return (
                    <FormFileUpload
                        {...commonProps}
                        accept={itemField.accept || ''}
                        multiple={itemField.multiple}
                        maxFiles={itemField.maxFiles}
                        value={fieldValue as File | File[] | null}
                        onChange={(files: File[] | null) => handleUpdateField(itemIndex, itemField.id, files)}
                    />
                );
            
            case 'select':
                return (
                    <div className="flex flex-col gap-2 w-full">
                        {!itemField.compact && (
                            <FormLabel htmlFor={fieldId} required={itemField.validation?.required}>
                                {itemField.label}
                            </FormLabel>
                        )}
                        <Select onValueChange={(val: string) => handleUpdateField(itemIndex, itemField.id, val)} value={fieldValue as string || ''}>
                            <SelectTrigger className={cn(
                                itemField.className,
                                itemField.compact && itemField.validation?.required ? 'border-l-4 border-l-orange-400' : ''
                            )}>
                                <SelectValue placeholder={
                                    itemField.compact && itemField.validation?.required 
                                        ? `${itemField.placeholder || itemField.label} *` 
                                        : itemField.placeholder || (itemField.compact ? itemField.label : "Select...")
                                } />
                            </SelectTrigger>
                            <SelectContent>
                                <SelectGroup>
                                    {itemField.options?.map(opt => (
                                        <SelectItem key={opt.value} value={opt.value}>{opt.label}</SelectItem>
                                    ))}
                                </SelectGroup>
                            </SelectContent>
                        </Select>
                    </div>
                );
            
            case 'multi-select':
                // Check if this should behave as single-select (for searchable icon fields)
                const isSingleSelect = itemField.id === 'icon' || itemField.maxSelections === 1;
                
                if (isSingleSelect) {
                    // Handle as single-select with search capability
                    const currentValue = fieldValue as string || '';
                    return (
                        <div className="flex flex-col w-full">
                            {!itemField.compact && (
                                <FormLabel htmlFor={fieldId} required={itemField.validation?.required}>
                                    {itemField.label}
                                </FormLabel>
                            )}
                            <MultiSelector
                                values={currentValue ? [currentValue] : []}
                                onValuesChange={(values: string[]) => {
                                    // Only take the first/last selected value for single-select
                                    const newValue = values.length > 0 ? values[values.length - 1] : '';
                                    handleUpdateField(itemIndex, itemField.id, newValue);
                                }}
                                loop
                                className={cn(
                                    'w-full', 
                                    itemField.className,
                                    itemField.compact && itemField.validation?.required ? 'border-l-4 border-l-orange-400' : ''
                                )}
                            >
                                <MultiSelectorTrigger>
                                    <MultiSelectorInput placeholder={
                                        itemField.compact && itemField.validation?.required 
                                            ? `${itemField.placeholder || itemField.label} *` 
                                            : itemField.placeholder || (itemField.compact ? itemField.label : "Search and select...")
                                    } />
                                </MultiSelectorTrigger>
                                <MultiSelectorContent>
                                    <MultiSelectorList>
                                        {itemField.options?.map(opt => (
                                            <MultiSelectorItem key={opt.value} value={opt.value}>{opt.label}</MultiSelectorItem>
                                        ))}
                                    </MultiSelectorList>
                                </MultiSelectorContent>
                            </MultiSelector>
                        </div>
                    );
                } else {
                    // Handle as normal multi-select
                    return (
                        <div className="flex flex-col w-full">
                            {!itemField.compact && (
                                <FormLabel htmlFor={fieldId} required={itemField.validation?.required}>
                                    {itemField.label}
                                </FormLabel>
                            )}
                            <MultiSelector
                                values={(fieldValue as string[] | undefined) || []}
                                onValuesChange={(values: string[]) => handleUpdateField(itemIndex, itemField.id, values)}
                                loop
                                className={cn(
                                    'w-full', 
                                    itemField.className,
                                    itemField.compact && itemField.validation?.required ? 'border-l-4 border-l-orange-400' : ''
                                )}
                            >
                                <MultiSelectorTrigger>
                                    <MultiSelectorInput placeholder={
                                        itemField.compact && itemField.validation?.required 
                                            ? `${itemField.placeholder || itemField.label} *` 
                                            : itemField.placeholder || (itemField.compact ? itemField.label : "Select...")
                                    } />
                                </MultiSelectorTrigger>
                                <MultiSelectorContent>
                                    <MultiSelectorList>
                                        {itemField.options?.map(opt => (
                                            <MultiSelectorItem key={opt.value} value={opt.value}>{opt.label}</MultiSelectorItem>
                                        ))}
                                    </MultiSelectorList>
                                </MultiSelectorContent>
                            </MultiSelector>
                        </div>
                    );
                }
            
            default:
                return <div>Unsupported field type: {itemField.type}</div>;
        }
    };

    const getColSpanClass = (colSpan?: number): string => {
        switch (colSpan) {
            case 1: return 'col-span-1';
            case 2: return 'col-span-2';
            case 3: return 'col-span-3';
            case 4: return 'col-span-4';
            default: return 'col-span-4';
        }
    };

    return (
        <div className="w-full">
            <div className="flex flex-col gap-2">
                {items.map((item, index) => {
                    const isNewlyAdded = newlyAddedIndex === index;
                    
                    const animationClasses = isNewlyAdded 
                        ? "bg-neutral-50 transition-colors duration-1000 ease-out rounded-md" 
                        : "bg-transparent";
                    
                    return (
                        <div 
                            key={index} 
                            className={`relative ${animationClasses} p-2`}
                        >
                            {/* Header with title and remove button */}
                            <div className="flex items-center justify-between mb-4">
                                <h4 className="text-body font-body-bold text-default-font">
                                    {itemTitle} {index + 1}
                                </h4>
                                {items.length > minItems && (
                                    <Button3
                                        variant="destructive-tertiary"
                                        size="small"
                                        onClick={() => removeItem(index)}
                                    >
                                        <FeatherX className="w-4 h-4 mr-1" />
                                        {removeButtonText}
                                    </Button3>
                                )}
                            </div>

                            {/* Fields grid - same as regular form fields */}
                            <div className="grid grid-cols-4 gap-x-6 gap-y-4">
                                {itemFields.map((itemField) => (
                                    <div key={itemField.id} className={getColSpanClass(itemField.colSpan)}>
                                        {renderField(itemField, index, item as Record<string, unknown>)}
                                    </div>
                                ))}
                            </div>
                        </div>
                    );
                })}
            </div>

            {/* Add button */}
            {items.length < maxItems && (
                <Button3
                    variant="brand-secondary"
                    className="mt-6"
                    iconRight={<FeatherPlus />}
                    onClick={handleAddItem}
                >
                    {addButtonText}
                </Button3>
            )}

            {/* Error display */}
            {error && (
                <div className="mt-2 text-red-500 text-sm pl-2">
                    {error}
                </div>
            )}

            {/* Item count info */}
            <div className="mt-2 text-sm text-gray-500 pl-2">
                {items.length} of {maxItems} {itemTitle.toLowerCase()}s
                {minItems > 0 && ` (minimum ${minItems} required)`}
            </div>
        </div>
    );
}; 