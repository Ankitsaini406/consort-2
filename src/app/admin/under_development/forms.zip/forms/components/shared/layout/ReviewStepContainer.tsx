import React from 'react';

interface ReviewStepContainerProps {
  children: React.ReactNode;
  className?: string;
  maxWidth?: 'none' | 'sm' | 'md' | 'lg' | 'xl' | '2xl' | '3xl' | '4xl';
}

export const ReviewStepContainer: React.FC<ReviewStepContainerProps> = ({ 
  children, 
  className = "",
  maxWidth = '4xl'
}) => {
  const maxWidthClass = maxWidth === 'none' ? '' : `max-w-${maxWidth} mx-auto`;
  
  return (
    <div className={`w-full space-y-4 ${maxWidthClass} ${className}`}>
      {children}
    </div>
  );
}; 