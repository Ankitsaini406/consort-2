import React from 'react';

export interface FormLabelProps {
    htmlFor: string;
    children: React.ReactNode;
    required?: boolean;
    className?: string;
}

export const FormLabel: React.FC<FormLabelProps> = ({
    htmlFor,
    children,
    required = false,
    className = "",
}) => {
    return (
        <label 
            htmlFor={htmlFor} 
            className={`text-[13px] font-medium pl-2 text-default-font ${className}`}
        >
            {children} {required && <span className="text-red-500">*</span>}
        </label>
    );
}; 