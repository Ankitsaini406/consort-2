import React from 'react';
import { Textarea } from "@/components/ui/textarea";
import { cn } from '@/lib/utils';
import { FormLabel } from './FormLabel';

export interface FormTextAreaProps {
  id: string;
  label: string;
  placeholder?: string;
  value: string;
  onChange: (value: string) => void;
  required?: boolean;
  error?: string;
  className?: string;
  minHeight?: string;
  compact?: boolean; // New prop for compact mode
}

export const FormTextArea: React.FC<FormTextAreaProps> = ({
  id,
  label,
  placeholder,
  value,
  onChange,
  required = false,
  error,
  className,
  minHeight = "120px",
  compact = false,
}) => {
  // Enhanced placeholder for compact mode
  const enhancedPlaceholder = compact && required 
    ? `${placeholder || label} *` 
    : placeholder || (compact ? label : undefined);

  return (
    <div className="flex flex-col gap-2 w-full">
      {/* Show label only in non-compact mode */}
      {!compact && (
        <FormLabel htmlFor={id} required={required}>
          {label}
        </FormLabel>
      )}
      
      <textarea
        id={id}
        placeholder={enhancedPlaceholder}
        value={value}
        onChange={(e) => onChange(e.target.value)}
        style={{ minHeight }}
        className={cn(
          "flex w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50 resize-y",
          error ? "border-red-500 focus-visible:ring-red-500" : "",
          compact && required ? "border-l-4 border-l-amber-400" : "",
          className
        )}
      />
      
      {error && <span className="text-red-500 text-sm pl-2">{error}</span>}
    </div>
  );
}; 