import React, { useState, useEffect } from 'react';
import { FeatherUploadCloud, FeatherCheckCircle, FeatherTrash, FeatherFile, FeatherImage, FeatherFileText } from "@subframe/core";
import { FormFileUploadProps } from '../../../types';
import { FormLabel } from './FormLabel';

// File upload state interface
interface FileUploadState {
    file: File;
    progress: number;
    status: 'uploading' | 'complete' | 'error';
}

export const FormFileUpload: React.FC<FormFileUploadProps> = ({
    id,
    label,
    accept,
    multiple = false,
    maxFiles = 1,
    value,
    onChange,
    onRemove,
    required = false
}) => {
    const [fileStates, setFileStates] = useState<FileUploadState[]>([]);
    const [isDragging, setIsDragging] = useState(false);

    // Get file type icon based on file extension
    const getFileIcon = (fileName: string) => {
        const ext = fileName.split('.').pop()?.toLowerCase();
        if (['jpg', 'jpeg', 'png', 'gif', 'webp', 'svg'].includes(ext || '')) {
            return <FeatherImage className="w-5 h-5 text-blue-500" />;
        }
        if (ext === 'pdf') {
            return <FeatherFileText className="w-5 h-5 text-red-500" />;
        }
        return <FeatherFile className="w-5 h-5 text-neutral-500" />;
    };

    // Simulate upload progress for a file
    const simulateUpload = (file: File) => {
        const newFileState: FileUploadState = { file, progress: 0, status: 'uploading' };
        
        setFileStates(prev => [...prev, newFileState]);

        // Simulate upload progress
        const interval = setInterval(() => {
            setFileStates(prev => prev.map(fs => 
                fs.file === file 
                    ? { ...fs, progress: Math.min(fs.progress + 10, 100) }
                    : fs
            ));
        }, 100);

        // Complete upload after 1 second
        setTimeout(() => {
            clearInterval(interval);
            setFileStates(prev => prev.map(fs => 
                fs.file === file 
                    ? { ...fs, progress: 100, status: 'complete' }
                    : fs
            ));
        }, 1000);
    };

    // Handle file selection
    const handleFileSelect = (files: File[]) => {
        const validFiles = multiple ? files.slice(0, maxFiles) : [files[0]];
        
        // Start upload simulation for each file
        validFiles.forEach(simulateUpload);
        
        // Call onChange with the files immediately (for form state)
        onChange(validFiles);
    };

    // Handle input change
    const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        if (e.target.files) {
            const files = Array.from(e.target.files);
            handleFileSelect(files);
        }
    };

    // Handle drag events
    const handleDragOver = (e: React.DragEvent) => {
        e.preventDefault();
        setIsDragging(true);
    };

    const handleDragLeave = () => setIsDragging(false);

    const handleDrop = (e: React.DragEvent) => {
        e.preventDefault();
        setIsDragging(false);
        const droppedFiles = Array.from(e.dataTransfer.files);
        handleFileSelect(droppedFiles);
    };

    // Handle file removal
    const handleRemoveFile = (index: number) => {
        setFileStates(prev => prev.filter((_, i) => i !== index));
        if (onRemove) {
            onRemove(index);
        }
    };

    // Sync fileStates with external value changes
    useEffect(() => {
        const currentFiles = value ? (Array.isArray(value) ? value : [value]) : [];
        
        // If external value is cleared, clear our internal state
        if (currentFiles.length === 0) {
            setFileStates([]);
        }
    }, [value]);

    return (
        <div className="flex flex-col gap-3 w-full">
            <FormLabel htmlFor={id} required={required}>{label}</FormLabel>
            
            {/* Hidden file input - never focusable */}
            <input
                type="file"
                id={id}
                accept={accept}
                multiple={multiple}
                onChange={handleInputChange}
                className="hidden"
                tabIndex={-1}
            />
            
            {/* Clickable drop zone */}
            <label
                htmlFor={id}
                className={`block border-2 border-dashed rounded-lg p-6 text-center transition-all duration-200 cursor-pointer ${
                    isDragging 
                        ? 'border-brand-500 bg-brand-50' 
                        : 'border-neutral-300 hover:border-brand-400 hover:bg-neutral-50'
                }`}
                onDragOver={handleDragOver}
                onDragLeave={handleDragLeave}
                onDrop={handleDrop}
            >
                <div className="flex flex-col items-center gap-2">
                    <div className="w-12 h-12 bg-brand-100 rounded-full flex items-center justify-center">
                        <FeatherUploadCloud className="w-6 h-6 text-brand-600" />
                    </div>
                    <div>
                        <p className="text-sm font-medium text-neutral-700">
                            {isDragging ? 'Drop files here' : 'Upload files'}
                        </p>
                        <p className="text-xs text-neutral-500">
                            Drag and drop or click to browse
                        </p>
                        {accept && (
                            <p className="text-xs text-neutral-400 mt-1">
                                Accepts: {accept}
                            </p>
                        )}
                    </div>
                </div>
            </label>

            {fileStates.length > 0 && (
                <div className="space-y-3">
                    {fileStates.map((fileState, index) => (
                        <div key={index} className="p-3 border border-neutral-200 rounded-lg bg-white">
                            <div className="flex items-center gap-3 mb-2">
                                {getFileIcon(fileState.file.name)}
                                <div className="flex-1">
                                    <p className="text-sm font-medium text-neutral-700">{fileState.file.name}</p>
                                    <p className="text-xs text-neutral-500">{(fileState.file.size / 1024).toFixed(1)} KB</p>
                                </div>
                                {fileState.status === 'complete' && (
                                    <button
                                        onClick={() => handleRemoveFile(index)}
                                        className="p-1 hover:bg-neutral-100 rounded transition-colors"
                                    >
                                        <FeatherTrash className="w-4 h-4 text-red-500" />
                                    </button>
                                )}
                            </div>
                            
                            {fileState.status === 'uploading' && (
                                <div className="w-full bg-neutral-200 rounded-full h-2">
                                    <div 
                                        className="bg-brand-600 h-2 rounded-full transition-all duration-300"
                                        style={{ width: `${fileState.progress}%` }}
                                    />
                                </div>
                            )}
                            
                            {fileState.status === 'complete' && (
                                <div className="flex items-center gap-1 text-green-600">
                                    <FeatherCheckCircle className="w-4 h-4" />
                                    <span className="text-xs">Upload complete</span>
                                </div>
                            )}
                            
                            {fileState.status === 'error' && (
                                <div className="flex items-center gap-1 text-red-600">
                                    <span className="text-xs">Upload failed</span>
                                </div>
                            )}
                        </div>
                    ))}
                </div>
            )}
        </div>
    );
}; 