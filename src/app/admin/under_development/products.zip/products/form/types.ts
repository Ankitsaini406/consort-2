export interface ProductResource {
  file: File | null;
  name?: string;
  url?: string;
}

export interface MarketingHighlight {
  id: string;
  headline: string;
  description: string;
  visuals: File[];
}

export interface KeyFeature {
  id: string;
  description: string;
}

export interface BulletPoint {
  id: string;
  content: string;
}

export interface ProductHighlight {
  id: string;
  productName: string;
  briefHeadline: string;
  productPhotos: File[];
}

export interface ProductFormData {
  portfolioCategory: string;
  targetIndustries: string[];
  brandName: string;
  clientCompanies: string[];
  globalTags: string[];
  productName: string;
  marketingTagline: string;
  productGallery: File[];
  productOverview: string;
  keyFeatures: KeyFeature[];
  datasheetFile: File | null;
  brochureFile: File | null;
  caseStudyFile: File | null;
  marketingHighlights: MarketingHighlight[];
  productIndex?: string;
  category?: string[];
  subCategory?: string;
  tags?: string[];
  briefHeadline?: string;
  briefDescription?: string;
  bulletPoints?: BulletPoint[];
  productPhotos?: File[];
  highlights?: ProductHighlight[];
  productResources?: {
    datasheet: ProductResource;
    brochure: ProductResource;
    caseStudies: ProductResource;
  };
  slug?: string;
  productBrief?: string;
  productKeyFeatures?: any[];
  briefHighlight?: string;
  [key: string]: unknown;
}

export interface FormSelectProps {
  id: string;
  label: string;
  value: string | string[];
  onChange: (value: string | string[]) => void;
  options: { label: string; value: string }[];
  placeholder?: string;
  multiple?: boolean;
  required?: boolean;
  error?: string;
} 