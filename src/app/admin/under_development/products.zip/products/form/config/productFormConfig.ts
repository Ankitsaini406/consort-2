import { FormConfig, FormFieldType } from '@/app/admin/forms/types';
import { ProductFormData } from '../types'; // Assuming this is the correct path
import { PRODUCT_CATEGORIES, PRODUCT_SUBCATEGORIES, COMPANY_TAGS, FILE_UPLOAD_CONFIG } from '../constants'; // Assuming this is the correct path

// Import custom components that will be used for 'custom-array' or 'custom-component' types
// import { HighlightsSection } from '../components/HighlightsSection'; // Replaced with dynamic-section
// import { BulletPointsSection } from '../components/BulletPointsSection'; // Replaced with dynamic-section
import { ReviewStep } from '../components/ReviewStep';

// Global tags options - this should ideally come from a shared constants file
const GLOBAL_TAGS_OPTIONS = [
    { value: 'ai', label: 'Artificial Intelligence' },
    { value: 'iot', label: 'Internet of Things' },
    { value: 'cloud', label: 'Cloud Computing' },
    { value: 'digital-transformation', label: 'Digital Transformation' },
    { value: 'automation', label: 'Automation' },
    { value: 'analytics', label: 'Analytics' },
    { value: 'security', label: 'Security' },
    { value: 'connectivity', label: 'Connectivity' },
    { value: 'innovation', label: 'Innovation' },
    { value: 'efficiency', label: 'Efficiency' },
];

const initialProductFormData: ProductFormData = {
    // New structure with updated variable names
    portfolioCategory: "", // Changed from productIndex
    targetIndustries: [], // Changed from category
    brandName: "", // Changed from subCategory
    clientCompanies: [], // Changed from tags
    globalTags: [], // NEW FIELD
    productName: "",
    marketingTagline: "", // Changed from briefHeadline
    productGallery: [], // Changed from productPhotos
    productOverview: "", // Changed from briefDescription
    keyFeatures: [{ id: "1", description: "" }], // Changed from bulletPoints
    datasheetFile: null, // Flattened from productResources.datasheet.file
    brochureFile: null, // Flattened from productResources.brochure.file
    caseStudyFile: null, // Flattened from productResources.caseStudies.file
    marketingHighlights: [{ id: "1", headline: "", description: "", visuals: [] }], // Changed from highlights

    // Legacy fields for backward compatibility - can be removed later
    productIndex: "",
    category: [],
    subCategory: "",
    tags: [],
    briefHeadline: "",
    briefDescription: "",
    bulletPoints: [{ id: "1", content: "" }],
    productPhotos: [],
    highlights: [{ id: "1", productName: "", briefHeadline: "", productPhotos: [] }],
    productResources: {
        datasheet: { file: null },
        brochure: { file: null },
        caseStudies: { file: null },
    },
    slug: "",
    productBrief: "",
    productKeyFeatures: [{ id: "1", type: "", content: "" }],
    briefHighlight: "",
};

export const productFormConfig: FormConfig<ProductFormData> = {
    formId: 'product-form',
    formTitle: 'Add Product',
    description: 'Fill in the details to add a new product to the catalog.',
    initialData: initialProductFormData,
    onSubmit: async (data, isDraft) => {
        console.log('Submitting Product Form:', data, 'Is Draft:', isDraft);
        // Replace with actual API submission logic
        await new Promise(resolve => setTimeout(resolve, 1000)); // Simulate API call
        if (data.productName === "fail") { // Example error condition
            throw new Error("Simulated server error: Product name cannot be 'fail'.");
        }
    },
    steps: [
        {
            id: 1,
            title: 'Product Details',
            subtitle: 'Product categorization and basic information',
            fields: [
                {
                    id: 'portfolioCategory', // Changed from productIndex
                    label: 'Select Portfolio Category',
                    type: 'select' as FormFieldType,
                    placeholder: 'Select portfolio category',
                    options: PRODUCT_CATEGORIES,
                    validation: { required: true },
                    colSpan: 1,
                },
                {
                    id: 'targetIndustries', // Changed from category
                    label: 'Target Industries',
                    type: 'multi-select' as FormFieldType,
                    placeholder: 'Select target industries',
                    options: PRODUCT_CATEGORIES, // Should be industry options
                    validation: { required: true },
                    colSpan: 3,
                },
                {
                    id: 'brandName', // Changed from subCategory
                    label: 'Select Brand',
                    type: 'select' as FormFieldType,
                    placeholder: 'Select brand',
                    options: PRODUCT_SUBCATEGORIES,
                    validation: { required: false },
                    colSpan: 1,
                },
                {
                    id: 'clientCompanies', // Changed from tags
                    label: 'Client Companies',
                    type: 'multi-select' as FormFieldType,
                    placeholder: 'Select client companies',
                    options: COMPANY_TAGS,
                    validation: { required: false },
                    colSpan: 3,
                },
                {
                    id: 'globalTags', // NEW FIELD
                    label: 'Global Tags',
                    type: 'multi-select' as FormFieldType,
                    placeholder: 'Select global tags for content linking',
                    options: GLOBAL_TAGS_OPTIONS,
                    validation: { required: false },
                    colSpan: 4,
                },
                {
                    id: 'productName',
                    label: 'Product Name',
                    type: 'input' as FormFieldType,
                    placeholder: 'Enter product name',
                    validation: { required: true, minLength: 3 },
                    colSpan: 4,
                },
                {
                    id: 'marketingTagline', // Changed from briefHeadline
                    label: 'Marketing Tagline',
                    type: 'textarea' as FormFieldType,
                    placeholder: 'Enter marketing tagline',
                    validation: { required: true, minLength: 10 },
                    colSpan: 4,
                },
                {
                    id: 'productGallery', // Changed from productPhotos
                    label: 'Upload Product Gallery (up to 4 photos)',
                    type: 'file' as FormFieldType,
                    accept: FILE_UPLOAD_CONFIG.PRODUCT_PHOTOS.accept,
                    multiple: true,
                    maxFiles: FILE_UPLOAD_CONFIG.PRODUCT_PHOTOS.maxFiles,
                    validation: { required: false },
                    colSpan: 4,
                },
            ],
        },
        {
            id: 2,
            title: 'Product Brief',
            subtitle: 'Detailed product information',
            fields: [
                {
                    id: 'productOverview', // Changed from briefDescription
                    label: 'Product Overview',
                    type: 'textarea' as FormFieldType,
                    placeholder: 'Enter detailed product overview',
                    validation: { required: true, minLength: 20 },
                    className: 'min-h-[150px]',
                    colSpan: 4,
                },
                {
                    id: 'keyFeatures', // Changed from bulletPoints
                    label: 'Key Features',
                    type: 'dynamic-section' as FormFieldType,
                    maxItems: 10,
                    minItems: 0,
                    addButtonText: 'Add Key Feature',
                    removeButtonText: 'Remove',
                    itemTitle: 'Key Feature',
                    itemFields: [
                        {
                            id: 'description', // Changed from content
                            label: 'Feature Description',
                            type: 'input' as FormFieldType,
                            placeholder: 'Enter key feature description',
                            validation: { required: true },
                            colSpan: 4,
                            compact: true,
                        },
                    ],
                    validation: { required: false },
                    colSpan: 4,
                },
            ],
        },
        {
            id: 3,
            title: 'Product Resources',
            subtitle: 'Upload product documents',
            fields: [
                {
                    id: 'datasheetFile', // Flattened from productResources.datasheet.file
                    label: 'Upload Datasheet PDF',
                    type: 'file' as FormFieldType,
                    accept: FILE_UPLOAD_CONFIG.DOCUMENTS.accept,
                    multiple: false,
                    colSpan: 2,
                },
                {
                    id: 'brochureFile', // Flattened from productResources.brochure.file
                    label: 'Upload Brochure PDF',
                    type: 'file' as FormFieldType,
                    accept: FILE_UPLOAD_CONFIG.DOCUMENTS.accept,
                    multiple: false,
                    colSpan: 2,
                },
                {
                    id: 'caseStudyFile', // Flattened from productResources.caseStudies.file
                    label: 'Upload Case Study PDF',
                    type: 'file' as FormFieldType,
                    accept: FILE_UPLOAD_CONFIG.DOCUMENTS.accept,
                    multiple: false,
                    colSpan: 4,
                },
            ],
        },
        {
            id: 4,
            title: 'Marketing Highlights',
            subtitle: 'Marketing selling points with visuals',
            fields: [
                {
                    id: 'marketingHighlights', // Changed from highlights
                    label: 'Marketing Highlights',
                    type: 'dynamic-section' as FormFieldType,
                    maxItems: 8,
                    minItems: 0,
                    addButtonText: 'Add Marketing Highlight',
                    removeButtonText: 'Remove',
                    itemTitle: 'Marketing Highlight',
                    itemFields: [
                        {
                            id: 'headline', // Changed from productName
                            label: 'Headline',
                            type: 'input' as FormFieldType,
                            placeholder: 'Enter highlight headline (7-10 words)',
                            validation: { required: true },
                            colSpan: 4,
                            compact: true,
                        },
                        {
                            id: 'description', // Changed from briefHeadline
                            label: 'Description',
                            type: 'textarea' as FormFieldType,
                            placeholder: 'Enter highlight description',
                            validation: { required: true },
                            colSpan: 4,
                            compact: true,
                        },
                        {
                            id: 'visuals', // Changed from productPhotos
                            label: 'Visuals / Illustrations',
                            type: 'file' as FormFieldType,
                            accept: FILE_UPLOAD_CONFIG.PRODUCT_PHOTOS.accept,
                            multiple: true,
                            maxFiles: FILE_UPLOAD_CONFIG.PRODUCT_PHOTOS.maxFiles,
                            colSpan: 4,
                        },
                    ],
                    validation: { required: false },
                    colSpan: 4,
                },
            ],
        },
        {
            id: 5,
            title: 'Review & Submit',
            subtitle: 'Please review all information before submitting',
            fields: [
                {
                    id: 'reviewStepDisplay',
                    label: '',
                    type: 'custom-component' as FormFieldType,
                    renderComponent: ReviewStep as any,
                    colSpan: 4,
                },
            ],
        },
    ],
}; 