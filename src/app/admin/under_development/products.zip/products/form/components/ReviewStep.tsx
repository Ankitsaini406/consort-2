import React from 'react';
import { ProductFormData } from '../types';
import { 
    SummaryCard, 
    GridFieldDisplay, 
    BaseReviewStepProps, 
    ReviewStepContainer,
    EmptyState,
    NestedGrid,
    SectionDivider
} from '@/app/admin/forms/components/shared/layout/SummaryCard';

interface ReviewStepProps extends BaseReviewStepProps<ProductFormData> {
    // Keep existing interface for backward compatibility
    onEditSection: (stepId: number | string) => void;
}

export const ReviewStep: React.FC<ReviewStepProps> = ({ 
    formData, 
    onEditSection, 
    className 
}) => {
    // Step IDs from productFormConfig.ts for navigation
    const stepIds = {
        productDetails: 1,
        productBrief: 2,
        resources: 3,
        highlights: 4,
    };

    return (
        <ReviewStepContainer className={className}>
            <SummaryCard 
                title="Product Details" 
                onEdit={() => onEditSection(stepIds.productDetails)}
                useGrid={true}
            >
                <GridFieldDisplay 
                    label="Portfolio Category" 
                    value={formData.portfolioCategory || formData.productIndex}
                />
                <GridFieldDisplay 
                    label="Brand Name" 
                    value={formData.brandName || formData.subCategory}
                />
                <GridFieldDisplay 
                    label="Target Industries" 
                    value={formData.targetIndustries || formData.category}
                    type="tags" 
                />
                <GridFieldDisplay 
                    label="Client Companies" 
                    value={formData.clientCompanies || formData.tags}
                    type="tags" 
                />
                <GridFieldDisplay 
                    label="Global Tags" 
                    value={formData.globalTags}
                    type="tags" 
                    colSpan={2}
                />
                <GridFieldDisplay 
                    label="Product Name" 
                    value={formData.productName} 
                />
                <GridFieldDisplay 
                    label="Marketing Tagline" 
                    value={formData.marketingTagline || formData.briefHeadline}
                    type="textarea"
                    colSpan={1}
                />
                <GridFieldDisplay 
                    label="Product Gallery" 
                    value={Array.isArray(formData.productGallery) ? formData.productGallery.map(photo => photo.name || 'Uploaded file') : 
                           Array.isArray(formData.productPhotos) ? formData.productPhotos.map(photo => photo.name || 'Uploaded file') : []}
                    type="files" 
                    colSpan={2}
                />
            </SummaryCard>

            <SummaryCard 
                title="Product Brief" 
                onEdit={() => onEditSection(stepIds.productBrief)}
                useGrid={true}
            >
                <GridFieldDisplay 
                    label="Product Overview" 
                    value={formData.productOverview || formData.briefDescription}
                    type="textarea"
                    colSpan={2}
                />
                <GridFieldDisplay 
                    label="Key Features" 
                    value={Array.isArray(formData.keyFeatures) ? formData.keyFeatures.map(kf => kf.description) : 
                           Array.isArray(formData.bulletPoints) ? formData.bulletPoints.map(bp => bp.content) : []}
                    type="list"
                    colSpan={2}
                />
            </SummaryCard>

            <SummaryCard 
                title="Product Resources" 
                onEdit={() => onEditSection(stepIds.resources)}
                useGrid={true}
            >
                <GridFieldDisplay 
                    label="Datasheet" 
                    value={formData.datasheetFile?.name || formData.productResources?.datasheet?.file?.name}
                    type="file" 
                />
                <GridFieldDisplay 
                    label="Brochure" 
                    value={formData.brochureFile?.name || formData.productResources?.brochure?.file?.name}
                    type="file" 
                />
                <GridFieldDisplay 
                    label="Case Study" 
                    value={formData.caseStudyFile?.name || formData.productResources?.caseStudies?.file?.name}
                    type="file" 
                />
            </SummaryCard>

            <SummaryCard 
                title="Marketing Highlights" 
                onEdit={() => onEditSection(stepIds.highlights)}
                useGrid={false}
            >
                {/* Use new marketingHighlights field with fallback to legacy highlights */}
                {Array.isArray(formData.marketingHighlights) && formData.marketingHighlights.length > 0 ? (
                    formData.marketingHighlights.map((highlight, index) => (
                        <SectionDivider 
                            key={highlight.id || index} 
                            isLast={index === formData.marketingHighlights.length - 1}
                        >
                            <NestedGrid>
                                <GridFieldDisplay 
                                    label="Headline" 
                                    value={highlight.headline} 
                                />
                                <GridFieldDisplay 
                                    label="Visuals" 
                                    value={Array.isArray(highlight.visuals) ? highlight.visuals.map(visual => visual.name || 'Uploaded file') : []} 
                                    type="files"
                                    colSpan={1}
                                />
                                <GridFieldDisplay 
                                    label="Description" 
                                    value={highlight.description} 
                                    type="textarea"
                                    colSpan={2}
                                />
                            </NestedGrid>
                        </SectionDivider>
                    ))
                ) : Array.isArray(formData.highlights) && formData.highlights && formData.highlights.length > 0 ? (
                    // Fallback to legacy highlights structure
                    formData.highlights.map((highlight, index) => (
                        <SectionDivider 
                            key={highlight.id || index} 
                            isLast={index === (formData.highlights?.length || 0) - 1}
                        >
                            <NestedGrid>
                                <GridFieldDisplay 
                                    label="Name" 
                                    value={highlight.productName} 
                                />
                                <GridFieldDisplay 
                                    label="Photos" 
                                    value={Array.isArray(highlight.productPhotos) ? highlight.productPhotos.map(photo => photo.name || 'Uploaded file') : []} 
                                    type="files"
                                    colSpan={1}
                                />
                                <GridFieldDisplay 
                                    label="Headline" 
                                    value={highlight.briefHeadline} 
                                    type="textarea"
                                    colSpan={2}
                                />
                            </NestedGrid>
                        </SectionDivider>
                    ))
                ) : (
                    <EmptyState message="No marketing highlights added." />
                )}
            </SummaryCard>
        </ReviewStepContainer>
    );
}; 