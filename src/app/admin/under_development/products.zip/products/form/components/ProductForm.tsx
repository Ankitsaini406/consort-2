import React from 'react';
import { AppFormRenderer } from '@/app/admin/forms/components/AppFormRenderer';
import { productFormConfig } from '../config/productFormConfig';
import { ProductFormData } from '../types';

// Updated imports for base StepProgress and StepCard
import { StepProgress } from '@/app/admin/forms/components/shared/layout/StepProgress';
import { StepCard } from '@/app/admin/forms/components/shared/layout/StepCard';
import { UniversalFormActions } from '@/app/admin/forms/components/shared/layout/UniversalFormActions';
import { addDoc, collection } from 'firebase/firestore';
import { db } from '@/firebase/firebaseconfig';
import { FormErrorHandler, UserNotification, InputSanitizer } from '@/app/admin/forms/utils/errorHandler';
import { RateLimiter, withRateLimit } from '@/app/admin/forms/utils/rateLimiter';
import { FileUploadSecurity, ALLOWED_FILE_TYPES, FILE_SIZE_LIMITS } from '@/app/admin/forms/utils/fileUploadSecurity';

const sanitizeProductData = (data: ProductFormData): ProductFormData => {
    return {
        ...data,
        productName: InputSanitizer.sanitizeString(data.productName || ''),
        productBrief: InputSanitizer.sanitizeHTML(data.productBrief || ''),
        briefHeadline: InputSanitizer.sanitizeString(data.briefHeadline || ''),
        briefDescription: InputSanitizer.sanitizeHTML(data.briefDescription || ''),
        briefHighlight: InputSanitizer.sanitizeString(data.briefHighlight || ''),
        slug: InputSanitizer.sanitizeString(data.slug || ''),
        // Sanitize bullet points
        bulletPoints: data.bulletPoints?.map(bp => ({
            ...bp,
            content: InputSanitizer.sanitizeHTML(bp.content || '')
        })) || [],
        // Sanitize key features
        productKeyFeatures: data.productKeyFeatures?.map(kf => ({
            ...kf,
            content: InputSanitizer.sanitizeHTML(kf.content || '')
        })) || [],
        // Sanitize highlights
        highlights: data.highlights?.map(h => ({
            ...h,
            productName: InputSanitizer.sanitizeString(h.productName || ''),
            briefHeadline: InputSanitizer.sanitizeString(h.briefHeadline || '')
        })) || [],
        // Files and arrays of strings are handled separately and don't need sanitization
    };
};

const validateFiles = async (data: ProductFormData): Promise<string[]> => {
    const errors: string[] = [];
    
    // Validate product photos
    if (data.productPhotos && data.productPhotos.length > 0) {
        for (const file of data.productPhotos) {
            const validation = await FileUploadSecurity.validateFile(file, {
                allowedTypes: [...ALLOWED_FILE_TYPES.images],
                maxSize: FILE_SIZE_LIMITS.image,
                requireSignatureValidation: true
            });
            
            if (!validation.isValid) {
                errors.push(`Product photo "${file.name}": ${validation.errors.join(', ')}`);
            }
        }
    }
    
    // Validate resource files
    if (data.productResources) {
        const resources = [
            data.productResources.datasheet?.file,
            data.productResources.brochure?.file,
            data.productResources.caseStudies?.file
        ].filter(Boolean) as File[];
        
        for (const file of resources) {
            const validation = await FileUploadSecurity.validateFile(file, {
                allowedTypes: [...ALLOWED_FILE_TYPES.documents, ...ALLOWED_FILE_TYPES.images],
                maxSize: FILE_SIZE_LIMITS.document,
                requireSignatureValidation: true
            });
            
            if (!validation.isValid) {
                errors.push(`Resource file "${file.name}": ${validation.errors.join(', ')}`);
            }
        }
    }
    
    return errors;
};

const handleProductFormSubmit = async (data: ProductFormData, isDraft?: boolean) => {
    const context = 'ProductForm';
    const clientId = RateLimiter.getClientIdentifier();
    
    try {
        // Apply rate limiting
        await withRateLimit(clientId, 'formSubmission', async () => {
            console.log(`[${context}] Submit started:`, { isDraft });
            
            // Validate files first
            const fileErrors = await validateFiles(data);
            if (fileErrors.length > 0) {
                throw new Error(`File validation failed: ${fileErrors.join('; ')}`);
            }
            
            // Sanitize input data
            const sanitizedData = sanitizeProductData(data);
            
            // Simulate processing delay
            await new Promise(resolve => setTimeout(resolve, 1500));
            
            // Test error simulation
            if (sanitizedData.productName === "force_error") {
                throw new Error("This is a simulated API error during product submission.");
            }
            
            // Add document to Firebase
            const docRef = await addDoc(collection(db, "products"), sanitizedData);
            
            // Success notification
            UserNotification.showSuccess(`Product "${sanitizedData.productName}" saved successfully with ID: ${docRef.id}`);
            console.log(`[${context}] Submit successful:`, { docId: docRef.id });
        });
        
    } catch (error) {
        // Handle and log error
        const formError = FormErrorHandler.handleError(error);
        FormErrorHandler.logError(error, context);
        UserNotification.showError(formError);
        
        // Re-throw to let the form handle the error state
        throw error;
    }
};

// Product-specific FormActions wrapper
const ProductFormActions: React.FC<React.ComponentProps<typeof UniversalFormActions>> = (props) => (
    <UniversalFormActions {...props} submitText="Submit Product" />
);

export const ProductForm: React.FC = () => {
    const configWithActualSubmit = {
        ...productFormConfig,
        onSubmit: handleProductFormSubmit,
    };

    return (
        <AppFormRenderer<ProductFormData>
            formConfig={configWithActualSubmit}
            StepProgressComponent={StepProgress}
            StepCardComponent={StepCard}
            FormActionsComponent={ProductFormActions}
        />
    );
};