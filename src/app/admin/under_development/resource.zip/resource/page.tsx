'use client';
import React from 'react';
import { AppFormRenderer } from '@/app/admin/forms/components/AppFormRenderer';
import { resourceFormConfig } from './form/config/resourceFormConfig';
import { ResourceFormData } from './types';
import { DefaultPageLayout } from '@/ui/layouts/DefaultPageLayout';
import { ResourceFormActions } from './form/components/ResourceFormActions';

const AdminResourcePage = () => {
    const handleSubmit = async (data: ResourceFormData) => {
        console.log('Resource form submitted:', data);
        // Here you would typically send the data to your backend API
        await new Promise(resolve => setTimeout(resolve, 1000)); // Simulate API call
        alert('Resource submitted successfully (check console)!');
    };

    return (
        <DefaultPageLayout title="Manage Resources">
            <AppFormRenderer<ResourceFormData>
                formConfig={{ ...resourceFormConfig, onSubmit: handleSubmit }}
                FormActionsComponent={ResourceFormActions} 
            />
        </DefaultPageLayout>
    );
};

export default AdminResourcePage;
