import { FormConfig, FormFieldType } from '@/app/admin/forms/types';
import { ResourceFormData, ResourceType, resourceTypeOptions, mockIndustryOptions, mockTagOptions } from '@/app/admin/resource/types'; // Adjusted path
import { ResourceSectionCustomArray } from '../components/ResourceSectionCustomArray';

export const resourceFormConfig: FormConfig<ResourceFormData> = {
    formId: 'resourceForm',
    formTitle: 'Add New Resource',
    description: 'Fill in the details to add a new resource to the platform.',
    initialData: {
        resourceType: '' as ResourceType | '',
        industryUseCase: [],
        resourceTitle: '',
        globalTags: [],
        headline: '',
        heroImage: null,
        contentSections: [],
    },
    onSubmit: async (data, isDraft) => {
        console.log('Form Submitted!', { data, isDraft });
        // Here you would typically send the data to your backend API
        // For file uploads, data.heroImage and images within data.contentSections
        // will be File objects that need to be handled (e.g., uploaded to a server or cloud storage).
        await new Promise(resolve => setTimeout(resolve, 1000)); // Simulate API call
        // throw new Error("Simulated submission error!"); // Uncomment to test error handling
    },
    steps: [
        {
            id: 'basicInfo',
            title: 'Resource Details',
            subtitle: 'Provide the basic information for the resource.',
            fields: [
                {
                    id: 'resourceType',
                    label: 'Resource Type',
                    type: 'select' as FormFieldType,
                    options: resourceTypeOptions,
                    validation: { required: true },
                    placeholder: 'Select a resource type',
                },
                {
                    id: 'resourceTitle',
                    label: 'Resource Title',
                    type: 'input' as FormFieldType,
                    validation: { required: true, minLength: 3 },
                    placeholder: 'Enter the main title for the resource',
                    colSpan: 2, // Example: make title span full width if layout is 2 columns
                },
                {
                    id: 'industryUseCase',
                    label: 'Industry Use Case',
                    type: 'multi-select' as FormFieldType,
                    options: mockIndustryOptions, // Replace with actual data source if available
                    placeholder: 'Select relevant industries',
                },
                {
                    id: 'globalTags',
                    label: 'Global Tags',
                    type: 'multi-select' as FormFieldType,
                    options: mockTagOptions, // Replace with actual data source if available
                    placeholder: 'Add global tags',
                },
                {
                    id: 'headline',
                    label: 'Headline / Short Description',
                    type: 'textarea' as FormFieldType,
                    placeholder: 'Enter a brief headline or description',
                    validation: { maxLength: 300 },
                    colSpan: 2, // Example: make headline span full width
                },
                {
                    id: 'heroImage',
                    label: 'Upload Hero Image',
                    type: 'file' as FormFieldType,
                    accept: 'image/*',
                    multiple: false,
                    colSpan: 2, // Example: make file upload span full width
                },
            ],
            layoutColumns: 2, // Arrange basic info in 2 columns
        },
        {
            id: 'contentSectionsStep',
            title: 'Content Sections',
            subtitle: 'Add and manage content sections for the resource.',
            fields: [
                {
                    id: 'contentSections',
                    label: '' /* Label handled by custom component */,
                    type: 'custom-array' as FormFieldType,
                    renderComponent: ResourceSectionCustomArray as any, // Cast for now
                    // No validation here for the array itself, but item validations are in getItemFieldConfig
                    // Max items (6) is enforced in ResourceSectionCustomArray
                    colSpan: 1, // The custom array component will take the full width of this single column
                },
            ],
            layoutColumns: 1, // The custom array component will manage its own layout internally
        },
        // Optional: Add a Review Step if needed
    ],
}; 