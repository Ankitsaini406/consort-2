import React, { useState, useCallback } from 'react';
import { CustomArrayFieldProps, FormField, FormFieldType, AppFormErrors } from '@/app/admin/forms/types';
import { ResourceSectionItem } from '@/app/admin/resource/types'; 
import { Button } from "@/components/ui/button";
import { FormInput } from '@/app/admin/forms/components/shared/fields/FormInput';
import { FormTextArea } from '@/app/admin/forms/components/shared/fields/FormTextArea';
import { FormFileUpload } from '@/app/admin/forms/components/shared/fields/FormFileUpload';
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible";
import { ChevronDown, ChevronUp, PlusCircle, Trash2 } from 'lucide-react';

interface InternalRenderFieldProps {
    fieldConfig: FormField;
    value: unknown;
    onChange: (value: unknown) => void;
    error?: string;
    touched?: boolean;
}

const InternalRenderField: React.FC<InternalRenderFieldProps> = React.memo(({ fieldConfig, value, onChange, error, touched }) => {
    const commonStyledInputProps = {
        id: fieldConfig.id,
        label: fieldConfig.label,
        value: value as string || '',
        onChange: (val: string) => onChange(val),
        placeholder: fieldConfig.placeholder,
        error: error,
        required: fieldConfig.validation?.required,
        className: `${fieldConfig.className || ''} ${error && touched ? 'border-red-500' : ''}`,
    };

    switch (fieldConfig.type) {
        case 'input':
            return <FormInput {...commonStyledInputProps} type="text" />;
        case 'textarea':
            return <FormTextArea {...commonStyledInputProps} />;
        case 'file':
            return <FormFileUpload 
                        id={fieldConfig.id}
                        label={fieldConfig.label}
                        value={value as File | File[] | null}
                        onChange={(files) => onChange(fieldConfig.multiple ? files : (files?.[0] || null))}
                        onRemove={() => {
                            if (!fieldConfig.multiple) {
                                onChange(null);
                            } else {
                                onChange([]);
                            }
                        }}
                        accept={fieldConfig.accept}
                        multiple={fieldConfig.multiple} 
                        maxFiles={fieldConfig.maxFiles}
                    />;
        default:
            return <p>Unsupported field type in section: {fieldConfig.type}</p>;
    }
});
InternalRenderField.displayName = 'InternalRenderField';

export const ResourceSectionCustomArray: React.FC<CustomArrayFieldProps<ResourceSectionItem>> = (props) => {
    const { 
        field, 
        items,
        addItem, 
        removeItem, 
        updateItem, 
        formData,
        getNestedValue = (obj: Record<string, unknown> | null | undefined, path: string): unknown => { 
            if (!obj) return undefined;
            return path.split('.').reduce((acc, part) => 
                (acc && typeof acc === 'object' && part in acc) ? (acc as Record<string, unknown>)[part] : undefined, 
            obj as unknown);
        },
        errors = {} as AppFormErrors, 
        touchedFields = {} as Record<string, boolean>,
        onBlur = (_fieldId: string) => {},
    } = props;

    const [openSections, setOpenSections] = useState<Record<string, boolean>>({});
    const sections = items || [];

    const toggleSection = (itemId: string) => {
        setOpenSections(prev => ({ ...prev, [itemId]: !prev[itemId] }));
    };

    const handleAddSection = () => {
        if (sections.length < 6) {
            addItem({
                id: String(Date.now() + Math.random()),
                sectionTitle: '',
                sectionDescriptionHeading: '',
                sectionDescriptionText: '',
                sectionImage: null,
                sectionBulletPoints: [],
            });
        } else {
            console.warn("Maximum of 6 sections allowed.");
        }
    };

    const handleRemoveSection = (idOrIndex: string | number) => {
        removeItem(idOrIndex);
    };

    const handleItemPartChange = useCallback((itemId: string, itemProperty: keyof Omit<ResourceSectionItem, 'id' | 'sectionBulletPoints'>, itemValue: unknown) => {
        updateItem(itemId, (currentItem) => ({
            ...currentItem,
            [itemProperty]: itemValue,
        }));
    }, [updateItem]);
    
    const addBulletPointToSection = useCallback((itemId: string) => {
        updateItem(itemId, (currentItem) => ({
            ...currentItem,
            sectionBulletPoints: [...(currentItem.sectionBulletPoints || []), ""],
        })); 
    }, [updateItem]);

    const updateBulletPointInSection = useCallback((itemId: string, bpIndex: number, bpValue: string) => {
        updateItem(itemId, (currentItem) => {
            const newBulletPoints = [...(currentItem.sectionBulletPoints || [])];
            newBulletPoints[bpIndex] = bpValue;
            return {
                ...currentItem,
                sectionBulletPoints: newBulletPoints,
            };
        });
    }, [updateItem]);

    const removeBulletPointFromSection = useCallback((itemId: string, bpIndex: number) => {
        updateItem(itemId, (currentItem) => ({
            ...currentItem,
            sectionBulletPoints: (currentItem.sectionBulletPoints || []).filter((_, i) => i !== bpIndex),
        })); 
    }, [updateItem]);

    const getItemFieldConfiguration = useCallback((itemProperty: keyof Omit<ResourceSectionItem, 'id' | 'sectionBulletPoints'>, item: ResourceSectionItem): FormField => {
        const baseIdPart = item.id;
        const fullFieldPath = `${field.id}.${baseIdPart}.${itemProperty}`; 

        let type: FormFieldType = 'input';
        let label = itemProperty.toString();
        let validation: FormField['validation'] = {};
        let accept: string | undefined = undefined;
        let multiple: boolean | undefined = undefined;
        let maxFiles: number | undefined = undefined;

        switch (itemProperty) {
            case 'sectionTitle': 
                label = 'Section Title'; 
                validation = { required: true, minLength: 2 }; 
                break;
            case 'sectionDescriptionHeading': 
                label = 'Section Description Heading'; 
                type = 'textarea'; 
                break;
            case 'sectionDescriptionText': 
                label = 'Section Description Text'; 
                type = 'textarea'; 
                validation = { required: true }; 
                break;
            case 'sectionImage': 
                label = 'Section Image'; 
                type = 'file'; 
                accept = 'image/*';
                multiple = false;
                maxFiles = 1;
                break;
        }
        return { id: fullFieldPath, label, type, validation, accept, placeholder: `Enter ${label.toLowerCase()}`, multiple, maxFiles };
    }, [field.id]);
    
    return (
        <div className="space-y-4">
            {sections.map((item, index) => {
                const itemId = item.id;
                if (!itemId) {
                    console.error("Section item missing ID at index:", index, item);
                    return null;
                }

                const sectionTitleConfig = getItemFieldConfiguration('sectionTitle', item);
                const sectionDescHeadingConfig = getItemFieldConfiguration('sectionDescriptionHeading', item);
                const sectionDescTextConfig = getItemFieldConfiguration('sectionDescriptionText', item);
                const sectionImageConfig = getItemFieldConfiguration('sectionImage', item);

                return (
                    <Collapsible 
                        key={itemId} 
                        open={openSections[itemId] !== undefined ? openSections[itemId] : true} 
                        onOpenChange={() => toggleSection(itemId)}
                        className="border rounded-md p-0 shadow-sm"
                    >
                        <div className="flex items-center justify-between px-4 py-3 bg-slate-50 dark:bg-slate-800 rounded-t-md">
                            <CollapsibleTrigger asChild>
                                <button type="button" className="flex items-center gap-2 text-sm font-medium w-full text-left">
                                    {openSections[itemId] ? <ChevronUp className="h-4 w-4" /> : <ChevronDown className="h-4 w-4" />}
                                    {item.sectionTitle || `Section ${index + 1}`}
                                </button>
                            </CollapsibleTrigger>
                            <Button type="button" variant="ghost" size="sm" onClick={() => handleRemoveSection(itemId)} className="text-destructive hover:text-destructive">
                                <Trash2 className="h-4 w-4" />
                            </Button>
                        </div>
                        <CollapsibleContent className="p-4 space-y-4 border-t bg-white dark:bg-slate-800/30 rounded-b-md">
                            {[sectionTitleConfig, sectionDescHeadingConfig, sectionDescTextConfig, sectionImageConfig].map(fieldConfigForItem => {
                                const valueAtPath = getNestedValue(formData, fieldConfigForItem.id); 
                                const currentError = errors[fieldConfigForItem.id];
                                const currentTouched = touchedFields[fieldConfigForItem.id];
                                const itemKey = fieldConfigForItem.id.substring(fieldConfigForItem.id.lastIndexOf('.') + 1) as keyof Omit<ResourceSectionItem, 'id' | 'sectionBulletPoints'>;

                                return (
                                    <div key={fieldConfigForItem.id} onBlur={() => onBlur(fieldConfigForItem.id)}>
                                        <InternalRenderField 
                                            fieldConfig={fieldConfigForItem}
                                            value={valueAtPath}
                                            onChange={(newValue) => handleItemPartChange(itemId, itemKey, newValue)}
                                            error={currentError}
                                            touched={currentTouched}
                                        />
                                        {currentError && currentTouched && <p className="text-xs text-red-500 mt-1">{currentError}</p>}
                                    </div>
                                );
                            })}

                            <div className="space-y-2 pt-2">
                                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300">Bullet Points</label>
                                {(item.sectionBulletPoints || []).map((bp, bpIndex) => {
                                    const bulletPointPath = `${field.id}.${itemId}.sectionBulletPoints.${bpIndex}`;
                                    const bpError = errors[bulletPointPath];
                                    const bpTouched = touchedFields[bulletPointPath];
                                    return (
                                        <div key={bpIndex} className="flex items-center gap-2">
                                            <FormInput 
                                                id={bulletPointPath}
                                                label={`Bullet Point ${bpIndex + 1}`}
                                                value={bp}
                                                onChange={(val) => updateBulletPointInSection(itemId, bpIndex, String(val))}
                                                placeholder={`Bullet Point ${bpIndex + 1}`}
                                                className={`${"flex-grow"} ${bpError && bpTouched ? 'border-red-500' : ''}`}
                                                error={bpError}
                                            />
                                            <Button type="button" variant="ghost" size="icon" onClick={() => removeBulletPointFromSection(itemId, bpIndex)} className="text-destructive hover:text-destructive-focus">
                                                <Trash2 className="h-4 w-4" />
                                            </Button>
                                        </div>
                                    );
                                })}
                                <Button type="button" variant="outline" size="sm" onClick={() => addBulletPointToSection(itemId)} className="mt-1">
                                    <PlusCircle className="h-4 w-4 mr-2" /> Add Bullet Point
                                </Button>
                            </div>
                        </CollapsibleContent>
                    </Collapsible>
                );
            })}
            {sections.length < 6 && (
                <Button type="button" variant="outline" onClick={handleAddSection} className="mt-4 w-full border-dashed hover:border-solid">
                    <PlusCircle className="h-4 w-4 mr-2" /> Add New Section (Max 6)
                </Button>
            )}
            {sections.length >= 6 && (
                 <p className="text-sm text-muted-foreground mt-2 text-center">Maximum of 6 sections reached.</p>
            )}
            {errors[field.id] && typeof errors[field.id] === 'string' && (
                <p className="text-xs text-red-500 mt-1">{errors[field.id] as string}</p>
            )}
        </div>
    );
}; 