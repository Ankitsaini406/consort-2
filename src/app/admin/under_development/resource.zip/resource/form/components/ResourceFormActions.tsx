import React from 'react';
import { Button3 } from '@/ui/components/Button3';
import { AppFormRendererActionHandlers } from '@/app/admin/forms/types';

export const ResourceFormActions: React.FC<AppFormRendererActionHandlers> = ({
    currentStep,
    totalSteps,
    onPrevious,
    onNext,
    onSubmit,
    isSubmitting,
    isCurrentStepValid,
    // submitButtonText = "Submit Resource",
    // previousButtonText = "Previous",
    // nextButtonText = "Next"
}) => {
    const isFirstStep = currentStep === 0;
    const isLastStep = currentStep === totalSteps - 1;

    return (
        <div className="flex justify-end space-x-3 pt-4 mt-6 border-t dark:border-slate-700">
            {!isFirstStep && (
                <Button3
                    variant="neutral-tertiary"
                    onClick={onPrevious}
                    disabled={isSubmitting}
                >
                    {/* {previousButtonText} */}
                    Previous
                </Button3>
            )}
            {!isLastStep && (
                <Button3
                    variant="brand-primary"
                    onClick={onNext}
                    disabled={isSubmitting || !isCurrentStepValid}
                >
                    {/* {nextButtonText} */}
                    Next
                </Button3>
            )}
            {isLastStep && (
                <Button3
                    variant="brand-primary"
                    onClick={() => onSubmit(false)}
                    disabled={isSubmitting || !isCurrentStepValid}
                    loading={isSubmitting}
                >
                    {/* {submitButtonText} */}
                    Submit Resource
                </Button3>
            )}
            {/* Example: Save as Draft button could be part of customActions or handled here */}
            {/* {isLastStep && (
                <Button3
                    variant="ghost"
                    onClick={() => onSubmit(true)}
                    disabled={isSubmitting}
                    className="ml-2"
                >
                    Save as Draft
                </Button3>
            )} */}
        </div>
    );
}; 