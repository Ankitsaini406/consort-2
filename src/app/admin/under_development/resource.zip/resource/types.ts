export enum ResourceType {
    BLOG_POST = "Blog Post",
    CASE_STUDY = "Case Study",
    NEWS = "News",
    EVENT = "Event",
    CLIENT_REVIEW = "Client Review",
    ANNOUNCEMENT = "Announcement",
    WHITEPAPER = "Whitepaper",
}

export interface ResourceSectionItem {
    id: string; // For unique identification in arrays
    sectionTitle: string;
    sectionDescriptionHeading?: string;
    sectionDescriptionText: string;
    sectionImage?: File | null;
    sectionBulletPoints: string[];
}

export interface ResourceFormData {
    resourceType: ResourceType | "";
    industryUseCase: string[]; // Assuming industry IDs or slugs
    resourceTitle: string;
    globalTags: string[];
    headline?: string;
    heroImage?: File | null;
    contentSections: ResourceSectionItem[];
    [key: string]: any; // Index signature to satisfy Record<string, unknown>
}

// Example for options if needed elsewhere, or they can be defined directly in config
export const resourceTypeOptions = Object.values(ResourceType).map(value => ({
    value: value,
    label: value
}));

// Mock industry options for now - these would likely come from a data source
export const mockIndustryOptions = [
    { value: "technology", label: "Technology" },
    { value: "healthcare", label: "Healthcare" },
    { value: "finance", label: "Finance" },
    { value: "education", label: "Education" },
    { value: "manufacturing", label: "Manufacturing" },
];

// Mock tag options for now
export const mockTagOptions = [
    { value: "ai", label: "AI" },
    { value: "cloud", label: "Cloud Computing" },
    { value: "data_security", label: "Data Security" },
    { value: "sustainability", label: "Sustainability" },
    { value: "innovation", label: "Innovation" },
]; 