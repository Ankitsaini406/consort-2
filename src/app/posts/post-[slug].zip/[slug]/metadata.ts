import { getBlogBySlug } from "./action";

type Props = {
    params: { slug: string };
};

export async function generateMetadata({ params }: Props) {
    const blog = await getBlogBySlug(params.slug);

    return {
        title: blog?.blogName ?? "Blog Not Found",
        description: blog?.description ?? "",
    };
}
