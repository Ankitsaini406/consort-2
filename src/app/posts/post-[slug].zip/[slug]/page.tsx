// import RelatedProducts from "@/components/RelatedProducts";
// import Questions from "@/components/CommonCTA";
import { fetchAllBlogs, getPostBySlug } from "./action";
import { FeatherCheckSquare, FeatherShare } from "@subframe/core";
import Image from "next/image";
import { BadgeConsort, Button3 } from "@/ui";

type Props = {
    params: { slug: string };
};

export async function generateStaticParams() {
    const blogs = await fetchAllBlogs();
    return blogs.map((blog) => ({ slug: blog.slug }));
}

export default async function BlogPage({ params }: Props) {
    const post = await getPostBySlug(params.slug);

    if (!post) {
        return <div className="p-8">Post not found</div>;
    }

    return (
        <div className="flex w-full max-w-[1024px] mx-auto flex-col items-start gap-6 rounded-md px-6 py-6 mobile:border mobile:border-solid mobile:border-neutral-border mobile:bg-transparent mobile:px-2 mobile:pt-0 mobile:pb-4">
            <div className="flex w-full flex-col items-start gap-2 px-1 lg:pt-12 md:pt-8 mobile:px-1 mobile:pt-8 mobile:pb-1">
                <div className="flex w-full flex-col items-start justify-center gap-4">
                    <div className="flex w-full items-center justify-between mobile:flex-col mobile:flex-nowrap mobile:items-start mobile:justify-start mobile:gap-6">
                        <div className="flex grow shrink-0 basis-0 flex-wrap items-start gap-2 px-1 py-1">
                            {post.globalTags.map((tag, index) => (
                                <BadgeConsort
                                    key={index}
                                    className="h-7 w-auto flex-none"
                                    variant="neutral"
                                    // icon={badge.icon ? iconMap[badge.icon] : undefined}
                                    iconRight={null}
                                >
                                    {tag}
                                </BadgeConsort>
                            ))}
                        </div>
                        <Button3
                            variant="destructive-tertiary"
                            size="small"
                            icon={<FeatherShare />}
                        // onClick={(event: React.MouseEvent<HTMLButtonElement>) => {}}
                        >
                            Share
                        </Button3>
                    </div>
                </div>
                <h2 className="w-full max-w-[768px] lg:text-heading-2 lg:font-heading-2 md:text-heading-3 md:font-heading-3 mobile:text-body-xl-bold mobile:font-body-xl-bold text-consort-blue ml-1.5 ">
                    {post.postTitle}
                </h2>
                <p className="max-w-[768px] text-body-lg font-body-lg text-subtext-color ml-1.5">
                    {post.headline}
                </p>
                {/* <div className="flex h-px w-full flex-none flex-col items-center gap-2 bg-neutral-border mt-1 mb-1.5" /> */}
                <Image
                    width={1000}
                    height={1000}
                    alt="LTE Train Radio System for Metro Rail"
                    className="max-h-[320px] w-full grow shrink-0 basis-0 rounded-md object-cover mt-4"
                    src={post.heroImage}
                />
            </div>

            {/* Content Section */}
            <div className="flex flex-col gap-12">
                {post.sections.map((section, index) => (
                    <div
                        key={index}
                        className={`flex w-full items-start gap-8} 
                        px-12 py-12 lg:flex-row md:flex-col md:gap-8 mobile:flex-col mobile:flex-nowrap mobile:gap-6 mobile:px-6 mobile:py-6`}>
                        {/* Left Sidebar Title */}
                        <div className="flex w-60 flex-none items-start gap-6 lg:sticky top-10 mobile:static">
                            <h3 className="lg:text-heading-3 lg:font-heading-3 md:text-heading-4 md:font-heading-4 mobile:text-heading-4 mobile:font-heading-4 text-consort-blue">
                                {section.sectionTitle}
                            </h3>
                        </div>

                        {/* Content Area */}
                            <div className="flex grow shrink-0 basis-0 flex-col items-start gap-4">
                                {/* Image Box */}
                                {section.sectionImage !==  null ? <div className="flex max-h-[768px] w-full flex-col items-start gap-2 overflow-hidden rounded-md bg-white px-4 py-4 shadow-sm">
                                    <Image
                                        width={1000}
                                        height={1000}
                                        className="w-full grow shrink-0 basis-0 object-contain"
                                        src={section.sectionImage || ''}
                                        alt={section.sectionTitle}
                                    />
                                </div> : null}
                                {/* Heading and Description */}
                                {section.sectionDescriptionHeading !== null &&
                                <h2 className="text-body-lg font-body-lg mobile:text-body mobile:font-body mobile:leading-snug text-consort-blue">
                                    {section.sectionDescriptionHeading}
                                </h2>}
                                {section.sectionDescriptionText && 
                                <p className="text-body font-body mobile:leading-snug text-subtext-color">
                                    {section.sectionDescriptionText}
                                </p>}
                                {section.sectionBulletPoints && <div className="flex flex-col items-start gap-4 px-2">
                                    {section.sectionBulletPoints.map((feature, index) => (
                                        <div key={index} className="flex items-start gap-4 mobile:gap-2 mobile:-ml-2">
                                            <FeatherCheckSquare className="text-body-lg font-body-lg mobile:text-caption text-consort-red mt-1" />
                                            <p className="text-body font-body mobile:leading-snug text-consort-blue">
                                                {feature.text}
                                            </p>
                                        </div>
                                    ))}
                                </div>}
                            </div>
                    </div>
                ))}
            </div>

            {/* Company Logos Carousel */}
            {/* <SingleRowCompanyLogos 
                logos={post.companyLogos} 
                title="Trusted by Transportation Leaders"
                delay={2400}
            /> */}

            {/* Related Products */}
            {/* <RelatedProducts items={post.relatedProducts.items} />

            {/* Case Studies */}
            {/* <CaseStudiesSection items={post.caseStudies.items} /> */}

        </div>
    )
}
