import { db } from "@/firebase/firebaseconfig";
import { Posts } from "@/types/types";
import { collection, doc, getDoc, getDocs } from "firebase/firestore";

export async function fetchAllBlogs(): Promise<Posts[]> {
    const blogsRef = collection(db, "posts");
    const snapshot = await getDocs(blogsRef);

    return snapshot.docs.map((doc) => {
        const data = doc.data();
        return {
            id: doc.id,
            slug: data.slug ?? doc.id,
            isDraft: data.isDraft ?? false,
            postTitle: data.postTitle ?? "Unnamed",
            globalTags: data.globalTags ?? [],
            headline: data.headline ?? "",
            heroImage: data.heroImage ?? "",
            industryUseCases: data.industryUseCases ?? [],
            numberOfSections: data.numberOfSections ?? 0,
            postType: data.postType ?? "post",
            sections: data.sections ?? [],
        };
    });
}

export async function getPostBySlug(slug: string): Promise<Posts | null> {
    if (!slug) return null;

    const docRef = doc(db, "posts", slug);
    const docSnap = await getDoc(docRef);

    if (!docSnap.exists()) return null;

    const data = docSnap.data();

    return {
        id: docSnap.id,
        slug: data.slug ?? docSnap.id,
        postTitle: data.postTitle ?? "Unnamed",
        globalTags: data.globalTags ?? [],
        headline: data.headline ?? "",
        heroImage: data.heroImage ?? "",
        industryUseCases: data.industryUseCases ?? [],
        isDraft: data.isDraft ?? false,
        numberOfSections: data.numberOfSections ?? 0,
        postType: data.postType ?? "post",
        sections: data.sections ?? [],
    };
}
