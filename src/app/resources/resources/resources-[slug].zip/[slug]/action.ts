import { db } from "@/firebase/firebaseconfig";
import { collection, doc, getDoc, getDocs } from "firebase/firestore";

type ResourceSection = {
    id: string;
    sectionDescriptionHeading: string;
    sectionDescriptionText: string;
    sectionImage: string;
    sectionTitle: string;
};


export type Resources = {
    globalTags: string[];
    headline: string;
    heroImage: string;
    industryUseCases: string[];
    postType: string;
    resourceTitle: string;
    resourceType: string;
    sections: ResourceSection[];
    slug: string;
};

export async function fetchAllResources(): Promise<Resources[]> {
    const resourcesRef = collection(db, "resources");
    const snapshot = await getDocs(resourcesRef);

    return snapshot.docs.map((doc) => {
        const data = doc.data();
        return {
            slug: doc.id,
            resourceTitle: data.resourceTitle ?? "Unnamed",
            globalTags: data.globalTags ?? [],
            headline: data.headline ?? "",
            heroImage: data.heroImage ?? "",
            industryUseCases: data.industryUseCases ?? [],
            postType: data.postType ?? "resource",
            resourceType: data.resourceType ?? "",
            sections: data.sections ?? [],
        };
    });
}

export async function getResourceBySlug(slug: string): Promise<Resources | null> {
    if (!slug) return null;

    const docRef = doc(db, "resources", slug);
    const docSnap = await getDoc(docRef);

    if (!docSnap.exists()) return null;

    const data = docSnap.data();

    return {
        slug: docSnap.id,
        resourceTitle: data.resourceTitle ?? "Unnamed",
        globalTags: data.globalTags ?? [],
        headline: data.headline ?? "",
        heroImage: data.heroImage ?? "",
        industryUseCases: data.industryUseCases ?? [],
        postType: data.postType ?? "resource",
        resourceType: data.resourceType ?? "",
        sections: data.sections ?? [],
    };
}
